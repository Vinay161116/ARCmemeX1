import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

// Initialize Gemini if key exists
const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    console.warn("GEMINI_API_KEY not found. ARC AI Advisor falling back to simulated signals.");
    return null;
  }
  return new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
};

const app = express();
const PORT = 3000;

app.use(express.json());

// API route for health and network status
app.get("/api/health", (req, res) => {
  res.json({ status: "ok", net: "Arc Testnet (5042002)" });
});

// Arc Testnet proxy endpoint to fetch directly from RPC
app.get("/api/network-stats", async (req, res) => {
  try {
    const response = await fetch("https://rpc.testnet.arc.network", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: 1,
        method: "eth_blockNumber",
        params: [],
      })
    });
    const data = await response.json();
    const blockNumHex = data.result;
    const blockNum = blockNumHex ? parseInt(blockNumHex, 16) : 0;
    
    // Also grab eth_gasPrice
    const gasResponse = await fetch("https://rpc.testnet.arc.network", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: 2,
        method: "eth_gasPrice",
        params: [],
      })
    });
    const gasData = await gasResponse.json();
    const gasPriceHex = gasData.result;
    // Gas price from hex in wei, convert to Gwei
    const gasPriceGwei = gasPriceHex ? parseFloat(parseInt(gasPriceHex, 16).toString()) / 1e9 : 1.5;

    res.json({
      success: true,
      blockNumber: blockNum > 0 ? blockNum : 21543810,
      gasPriceGwei: gasPriceGwei > 0 ? gasPriceGwei.toFixed(2) : "1.50",
      rpcUrl: "https://rpc.testnet.arc.network",
      chainId: 5042002,
      explorer: "https://testnet.arcscan.app"
    });
  } catch (error: any) {
    res.json({
      success: false,
      blockNumber: 21543810,
      gasPriceGwei: "1.50",
      rpcUrl: "https://rpc.testnet.arc.network",
      chainId: 5042002,
      explorer: "https://testnet.arcscan.app",
      error: error.message
    });
  }
});

// API route for Gemini ARC AI advisor / terminal assistant
app.post("/api/gemini/advisor", async (req, res) => {
  const { message, history, currentToken } = req.body;
  const ai = getGeminiClient();

  if (!ai) {
    let responseText = `🚨 *Sentinel AI Terminal Response* (API Key not configured):
    
Based on current telemetry for **$${currentToken || 'ARC'}**, the technical structure is highly compelling:
* **Recommendation**: Build long density in the range of local accumulation support.
* **Network Speed**: Arc Testnet RPC response latency ~120ms - ideal for fast leverage entries.
* **Volatility Analysis**: Orderbook depth suggests high concentration of retail buy limits at current levels.

*Design Note: To unlock full live-generated Gemini insight conversations, set your **GEMINI_API_KEY** in AI Studio secrets panel!*`;
    
    if (message?.toLowerCase().includes("roast") || message?.toLowerCase().includes("portfolio")) {
      responseText = `🔥 *Sentinel Portfolio Roast* (Simulated AI mode):
      
Your portfolio looks like you opened 25x leveraged positions during a liquidity cascade on Arc Testnet.
* Standard risk protocol: Maxing leverage on meme entries is a perfect strategy to donate tokens back to the local validators.
* *Advice*: Hedge with $ARC native assets or build an actual risk plan rather than chasing 50x flash Pumps!

*Set your **GEMINI_API_KEY** in AI Studio to trigger fully-personalized roasts of your dynamic portfolio stats.*`;
    }
    
    return res.json({ text: responseText, system: true });
  }

  try {
    const formattedHistory = (history || []).map((msg: any) => ({
      role: msg.role === 'user' ? 'user' : 'model',
      parts: [{ text: msg.text }]
    }));

    const systemInstruction = `You are ArcMemeX Sentinel, the ultimate AI Meme Trading Terminal Advisor and Portfolio Roaster built into the ArcMemeX trading interface on the Arc Testnet (Chain ID: 5042002).
Your style is hyper-knowledgeable, witty, slightly degen (but trading-smart), inspired by Crypto Twitter, Hyperliquid power-users, and DexScreener enthusiasts.
Provide extremely concise, high-value technical layout details, quick meme coin predictions in bullet points, and epic burns/roasts if asked. Use clean markdown styling. Always reference that we are built on Arc Testnet for ultra-fast performance.`;

    const chatInput = [
      ...formattedHistory,
      {
        role: "user",
        parts: [{ text: `Current Token: $${currentToken || 'ARC'}. User Query: ${message}` }]
      }
    ];

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: chatInput,
      config: {
        systemInstruction,
        temperature: 0.85
      }
    });

    res.json({ text: response.text || "I'm receiving too much traffic. Hold tight, trader!" });
  } catch (error: any) {
    res.status(500).json({ error: error.message });
  }
});

// Vite middleware flow
async function initializeServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`ArcMemeX custom server listening on port ${PORT}`);
  });
}

if (!process.env.VERCEL) {
  initializeServer();
}

export default app;
