import { useTradingState } from './useTradingState';
import Header from './components/Header';
import TradeTab from './components/TradeTab';
import TrendingTab from './components/TrendingTab';
import PortfolioTab from './components/PortfolioTab';
import WatchlistTab from './components/WatchlistTab';
import AiChatTab from './components/AiChatTab';
import { Activity, ShieldCheck, Link as LinkIcon, Cpu, ArrowUpRight } from 'lucide-react';

export default function App() {
  const state = useTradingState();

  return (
    <div className="min-h-screen bg-[#060709] text-zinc-300 font-sans flex flex-col justify-between">
      
      {/* Top sticky blockchain synchronized header navigation */}
      <Header
        activeTab={state.activeTab}
        setActiveTab={state.setActiveTab}
        wallet={state.wallet}
        connectWallet={state.connectWallet}
        disconnectWallet={state.disconnectWallet}
        switchNetworkToArc={state.switchNetworkToArc}
        networkStats={state.networkStats}
      />

      {/* Main active layout viewport rendering block */}
      <main className="flex-1 pb-10">
        {state.activeTab === 'trade' && (
          <TradeTab
            tokens={state.tokens}
            selectedTokenSymbol={state.selectedTokenSymbol}
            setSelectedTokenSymbol={state.setSelectedTokenSymbol}
            wallet={state.wallet}
            executeTrade={state.executeTrade}
            runFaucet={state.runFaucet}
          />
        )}

        {state.activeTab === 'trending' && (
          <TrendingTab
            tokens={state.tokens}
            watchlist={state.watchlist}
            toggleWatchlist={state.toggleWatchlist}
            onSelectToken={state.setSelectedTokenSymbol}
            setActiveTab={state.setActiveTab}
          />
        )}

        {state.activeTab === 'portfolio' && (
          <PortfolioTab
            tokens={state.tokens}
            wallet={state.wallet}
            positions={state.positions}
            transactions={state.transactions}
            closePosition={state.closePosition}
            setActiveTab={state.setActiveTab}
          />
        )}

        {state.activeTab === 'watchlist' && (
          <WatchlistTab
            tokens={state.tokens}
            watchlist={state.watchlist}
            toggleWatchlist={state.toggleWatchlist}
            onSelectToken={state.setSelectedTokenSymbol}
            setActiveTab={state.setActiveTab}
          />
        )}

        {state.activeTab === 'ai' && (
          <AiChatTab
            chatMessages={state.chatMessages}
            isAiLoading={state.isAiLoading}
            sendAiChatMessage={state.sendAiChatMessage}
            setChatMessages={state.setChatMessages}
            tokens={state.tokens}
            selectedTokenSymbol={state.selectedTokenSymbol}
          />
        )}
      </main>

      {/* Professional low-density terminal footer with telemetry */}
      <footer className="border-t border-zinc-900 bg-[#040507] px-4 py-2 text-[10.5px] font-mono text-zinc-500 select-none shrink-0 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center space-x-4">
          <span className="flex items-center space-x-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block animate-pulse"></span>
            <span>SECURE TERMINAL ACTIVE</span>
          </span>

          <span className="hidden sm:inline text-zinc-700">|</span>

          <span className="hidden sm:flex items-center space-x-1">
            <Cpu className="w-3.5 h-3.5 text-zinc-650" />
            <span>RPC ENDPOINT CALIBRATED</span>
          </span>
        </div>

        <div className="flex items-center space-x-3 text-zinc-500 bg-zinc-950 border border-zinc-900/50 px-2 py-0.5 rounded">
          <span>GAS: <span className="text-emerald-400 font-bold">{state.networkStats.gasPriceGwei} Gwei</span></span>
          <span className="text-zinc-800">|</span>
          <span>CHAIN-ID: <span className="text-zinc-400">5042002</span></span>
          <span className="text-zinc-800">|</span>
          <a
            href={state.networkStats.explorer}
            target="_blank"
            rel="noreferrer referrer"
            className="text-zinc-400 hover:text-emerald-400 transition-colors flex items-center space-x-0.5"
          >
            <span>Explorer</span>
            <ArrowUpRight className="w-3 h-3" />
          </a>
        </div>
      </footer>

    </div>
  );
}
