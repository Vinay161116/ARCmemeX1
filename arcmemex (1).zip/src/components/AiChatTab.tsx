import { useRef, useEffect, useState, FormEvent, KeyboardEvent } from 'react';
import { ChatMessage, MemeToken } from '../types';
import { Terminal, Send, Trash2, Bot, AlertTriangle, ShieldCheck } from 'lucide-react';

interface AiChatTabProps {
  chatMessages: ChatMessage[];
  isAiLoading: boolean;
  sendAiChatMessage: (text: string) => void;
  setChatMessages: (msgs: ChatMessage[]) => void;
  tokens: MemeToken[];
  selectedTokenSymbol: string;
}

export default function AiChatTab({
  chatMessages,
  isAiLoading,
  sendAiChatMessage,
  setChatMessages,
  tokens,
  selectedTokenSymbol,
}: AiChatTabProps) {
  const [inputText, setInputText] = useState('');
  const chatBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatMessages, isAiLoading]);

  // Initial welcome message if chat history is empty
  useEffect(() => {
    if (chatMessages.length === 0) {
      setChatMessages([
        {
          id: 'welcome',
          role: 'model',
          text: `👋 Greetings, ArcMemeX trader! I am **Sentinel AI**, your dedicated terminal advisor and risk controller.
          
* I scan the **Arc Testnet** for real-time order concentration.
* I calculate maintainable leverage models (up to 50x) depending on orderbook depth.
* I can **roast your active positions** if your leverage sizing looks reckless.

Try asking:
* *"What is the hot trend for $GIGA?"*
* *"Give me high leverage signals for the native token."*
* *"Roast my current positions."*`,
          timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
    }
  }, [chatMessages.length, setChatMessages]);

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    sendAiChatMessage(inputText);
    setInputText('');
  };

  const handleSuggestionClick = (suggestion: string) => {
    sendAiChatMessage(suggestion);
  };

  const handleKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      if (!inputText.trim()) return;
      sendAiChatMessage(inputText);
      setInputText('');
    }
  };

  return (
    <div className="p-4 max-w-4xl mx-auto space-y-4 h-[calc(100vh-140px)] flex flex-col animate-in fade-in duration-300">
      
      {/* Sentinel Title Header */}
      <div className="flex items-center justify-between border-b border-zinc-900 pb-3 shrink-0">
        <div className="flex items-center space-x-2.5">
          <div className="p-1.5 rounded bg-emerald-950/40 text-emerald-400 border border-emerald-900/40 shadow-[0_0_8px_rgba(16,185,129,0.2)]">
            <Bot className="w-5 h-5 animate-bounce" />
          </div>
          <div>
            <h3 className="font-display font-semibold text-sm text-zinc-100">Sentinel Trading Oracle</h3>
            <p className="text-[10px] text-zinc-500 font-mono">NODE ID: ARC-SENTINEL-9002-LIVE</p>
          </div>
        </div>

        {/* Clear chat logs button */}
        <button
          onClick={() => setChatMessages([])}
          className="text-zinc-600 hover:text-rose-400 text-xs flex items-center space-x-1.5 font-sans py-1 px-2 rounded hover:bg-zinc-950 transition-all cursor-pointer"
          title="Clear Chat Logs"
        >
          <Trash2 className="w-3.5 h-3.5" />
          <span className="hidden sm:inline">Flush Logs</span>
        </button>
      </div>

      {/* Terminal Conversation body scrolling */}
      <div className="flex-1 bg-[#040507] border border-zinc-950 rounded-lg p-4 overflow-y-auto space-y-4 scroll-smooth min-h-0 relative select-text">
        <div className="absolute top-2.5 right-3.5 flex items-center space-x-1.5 text-[9px] font-mono text-zinc-600 uppercase font-bold pointer-events-none">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
          <span>Encrypted RPC Link</span>
        </div>

        {chatMessages.map((msg) => {
          const isUser = msg.role === 'user';
          return (
            <div
              key={msg.id}
              className={`flex ${isUser ? 'justify-end' : 'justify-start'} w-full animate-in fade-in-30`}
            >
              <div className={`max-w-[85%] rounded-lg px-4 py-3 text-xs leading-relaxed font-sans ${
                isUser 
                  ? 'bg-zinc-900 text-zinc-100 border border-zinc-800 rounded-tr-none' 
                  : 'bg-[#0E1015] text-zinc-300 border border-zinc-950 rounded-tl-none font-mono whitespace-pre-line'
              }`}>
                {/* Meta details */}
                <div className="flex items-center space-x-1.5 pb-1 mb-1 border-b border-zinc-950 text-[10px] text-zinc-500 font-mono select-none">
                  <span>{isUser ? 'TRADER_CLIENT' : 'ORACLE_NODE_FEED'}</span>
                  <span>•</span>
                  <span>{msg.timestamp}</span>
                </div>

                {/* Message Text rendering with standard layout helpers */}
                <span className="prose prose-invert prose-xs text-xs break-words">
                  {msg.text}
                </span>
              </div>
            </div>
          );
        })}

        {/* Pending computer calculation ticker */}
        {isAiLoading && (
          <div className="flex justify-start w-full animate-pulse">
            <div className="bg-[#0E1015] border border-zinc-950 text-zinc-400 font-mono text-[11px] rounded-lg px-4 py-3 rounded-tl-none">
              <div className="flex items-center space-x-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping"></span>
                <span>Sentinel is computing block depths & order concentrations...</span>
              </div>
            </div>
          </div>
        )}

        <div ref={chatBottomRef}></div>
      </div>

      {/* Suggested Fast Question pills */}
      <div className="flex space-x-1.5 overflow-x-auto py-1 shrink-0 select-none scrollbar-none">
        {[
          { text: "Roast my positions", label: "🔥 Roast Portfolio" },
          { text: "fastest transaction layer", label: "⚡ Network Info" },
          { text: `Analyze model metrics for $${selectedTokenSymbol}`, label: `📊 Analyze $${selectedTokenSymbol}` },
          { text: "What is leverage liquidation?", label: "❓ Help Limit" }
        ].map((sug, i) => (
          <button
            key={i}
            onClick={() => handleSuggestionClick(sug.text)}
            className="bg-zinc-950 hover:bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-zinc-900 px-2.5 py-1 rounded text-[10px] font-mono whitespace-nowrap transition-all cursor-pointer"
          >
            {sug.label}
          </button>
        ))}
      </div>

      {/* Terminal prompt submission input */}
      <form onSubmit={handleSubmit} className="flex space-x-2 shrink-0">
        <textarea
          rows={1}
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={`Instruct Sentinel or request analysis of $${selectedTokenSymbol}... (Press Enter)`}
          className="flex-1 bg-[#060709] border border-zinc-900 rounded p-2.5 text-xs text-zinc-200 font-mono placeholder-zinc-650 focus:outline-none focus:border-emerald-500/40 focus:ring-1 focus:ring-emerald-500/10 resize-none max-h-12"
        />
        <button
          type="submit"
          className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950 px-4 rounded text-xs font-bold transition-all flex items-center justify-center shrink-0 shadow-[0_0_12px_rgba(16,185,129,0.2)] cursor-pointer"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>
    </div>
  );
}
