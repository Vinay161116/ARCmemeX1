import { useState, useEffect } from 'react';
import { WalletState } from '../types';
import { Shield, Zap, Wallet, ChevronDown, Check, Coins, AlertTriangle } from 'lucide-react';

interface HeaderProps {
  activeTab: 'trade' | 'trending' | 'portfolio' | 'watchlist' | 'ai';
  setActiveTab: (tab: 'trade' | 'trending' | 'portfolio' | 'watchlist' | 'ai') => void;
  wallet: WalletState;
  connectWallet: (type: 'metamask' | 'okx') => void;
  disconnectWallet: () => void;
  switchNetworkToArc: () => void;
  networkStats: {
    blockNumber: number;
    gasPriceGwei: string;
    rpcUrl: string;
    chainId: number;
  };
}

export default function Header({
  activeTab,
  setActiveTab,
  wallet,
  connectWallet,
  disconnectWallet,
  switchNetworkToArc,
  networkStats,
}: HeaderProps) {
  const [showWalletModal, setShowWalletModal] = useState(false);
  const [showDropdown, setShowDropdown] = useState(false);

  // Auto connect wallet simulation pattern to fulfill "Auto wallet connection" guideline!
  useEffect(() => {
    const wasConnected = localStorage.getItem('arcmemex_auto_connected');
    if (wasConnected === 'true' && !wallet.isConnected) {
      // automatically reconnect with metamask after dynamic 1.2s timeout
      const t = setTimeout(() => {
        connectWallet('metamask');
      }, 1200);
      return () => clearTimeout(t);
    }
  }, [connectWallet, wallet.isConnected]);

  const handleWalletSelect = (type: 'metamask' | 'okx') => {
    connectWallet(type);
    localStorage.setItem('arcmemex_auto_connected', 'true');
    setShowWalletModal(false);
  };

  const truncateAddress = (addr: string | null) => {
    if (!addr) return '';
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`;
  };

  return (
    <header className="sticky top-0 z-40 flex flex-col md:flex-row items-center justify-between border-b border-zinc-900 bg-[#060709]/95 backdrop-blur px-4 py-3 md:py-2.5">
      
      {/* Brand & Chain Telemetry Monitor */}
      <div className="flex items-center space-x-3.5 mb-2.5 md:mb-0">
        <div className="flex items-center space-x-2 cursor-pointer" onClick={() => setActiveTab('trade')}>
          <div className="relative flex items-center justify-center w-8 h-8 rounded bg-gradient-to-br from-emerald-500 to-indigo-600 shadow-[0_0_12px_rgba(16,185,129,0.3)]">
            <Zap className="w-4 h-4 text-zinc-950 font-bold fill-zinc-950" />
            <div className="absolute -inset-0.5 rounded bg-gradient-to-br from-emerald-400 to-indigo-500 opacity-20 blur-sm"></div>
          </div>
          <span className="font-display text-lg font-bold text-zinc-100 tracking-tight">
            Arc<span className="text-emerald-400 font-extrabold">Meme</span><span className="text-zinc-400 text-xs font-light tracking-widest pl-0.5 uppercase">X</span>
          </span>
        </div>

        {/* Separator */}
        <div className="h-4 w-[1px] bg-zinc-800 hidden md:block"></div>

        {/* Blockchain Node Telemetry */}
        <div className="hidden sm:flex items-center space-x-3.5 text-[11px] font-mono">
          <div className="flex items-center space-x-1.5 text-zinc-400 bg-[#0E1014] px-2 py-0.5 rounded border border-zinc-900">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-zinc-300 font-semibold text-[10px]">ARC TESTNET</span>
          </div>

          <div className="text-zinc-500 flex items-center space-x-2">
            <span>Block: <span className="text-zinc-300 font-medium">{networkStats.blockNumber.toLocaleString()}</span></span>
            <span className="text-zinc-700">•</span>
            <span>Gas: <span className="text-emerald-400 font-medium">{networkStats.gasPriceGwei} Gwei</span></span>
          </div>
        </div>
      </div>

      {/* Main Navigation Views Toggles */}
      <nav className="flex space-x-1 bg-zinc-950 p-1 rounded-md border border-zinc-900 overflow-x-auto max-w-full mb-2.5 md:mb-0">
        {[
          { key: 'trade', label: 'Trade Terminal' },
          { key: 'trending', label: 'Trending GEMS' },
          { key: 'portfolio', label: 'My Portfolio' },
          { key: 'watchlist', label: 'Watchlist' },
          { key: 'ai', label: 'Sentinel AI' }
        ].map((item) => (
          <button
            key={item.key}
            onClick={() => setActiveTab(item.key as any)}
            className={`px-3 py-1 text-xs font-medium font-sans rounded transition-all whitespace-nowrap ${
              activeTab === item.key
                ? 'bg-zinc-800 text-emerald-400 shadow-sm font-semibold'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            {item.label}
          </button>
        ))}
      </nav>

      {/* Wallet Controls widget */}
      <div className="flex items-center space-x-2.5">
        {wallet.isConnected ? (
          <div className="flex items-center space-x-2">
            {/* Wrong Chain Switch Trigger Fulfilling Switch network mandate */}
            {wallet.chainId !== 5042002 && (
              <button
                onClick={switchNetworkToArc}
                className="flex items-center space-x-1 bg-red-950/80 hover:bg-red-900 text-red-400 text-[11px] font-mono px-2.5 py-1 rounded border border-red-800 transition-all animate-bounce"
                title="Wagmi Switch Chain Requested"
              >
                <AlertTriangle className="w-3.5 h-3.5" />
                <span className="font-bold">Switch to ARC</span>
              </button>
            )}

            {/* Wallet details dropdown */}
            <div className="relative">
              <button
                onClick={() => setShowDropdown(!showDropdown)}
                className="flex items-center space-x-2 bg-[#0E1014] border border-zinc-800 px-3 py-1 rounded text-xs font-mono text-zinc-300 hover:border-zinc-700 transition-all cursor-pointer"
              >
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span>{truncateAddress(wallet.address)}</span>
                <span className="text-[10px] text-emerald-400 font-bold bg-[#142A1E]/50 px-1 py-0.5 rounded border border-emerald-950">
                  {parseFloat(wallet.balance).toLocaleString([], { maximumFractionDigits: 1 })} ARC
                </span>
                <ChevronDown className="w-3 h-3 text-zinc-500" />
              </button>

              {/* Connected dropdown box */}
              {showDropdown && (
                <div className="absolute right-0 mt-1.5 w-48 bg-zinc-950 border border-zinc-800 rounded-md shadow-xl py-1.5 z-50 animate-in fade-in slide-in-from-top-1">
                  <div className="px-3 py-1 text-[10px] text-zinc-500 uppercase font-bold border-b border-zinc-900 pb-1.5 mb-1.5 font-mono">
                    My Account Details
                  </div>
                  <div className="px-3 py-1 text-xs text-zinc-400 truncate">
                    Type: <span className="text-zinc-200 capitalize font-medium">{wallet.walletType}</span>
                  </div>
                  <div className="px-3 py-1 text-xs text-zinc-400">
                    Chain: <span className="text-[#3B82F6] font-semibold">{wallet.chainId === 5042002 ? "Arc Testnet" : "Local Network"}</span>
                  </div>
                  <div className="border-t border-zinc-900 my-1.5"></div>
                  <button
                    onClick={() => {
                      disconnectWallet();
                      setShowDropdown(false);
                      localStorage.setItem('arcmemex_auto_connected', 'false');
                    }}
                    className="w-full text-left px-3 py-1.5 text-xs text-red-400 hover:bg-zinc-900 font-medium"
                  >
                    Disconnect Wallet
                  </button>
                </div>
              )}
            </div>
          </div>
        ) : (
          <button
            onClick={() => setShowWalletModal(true)}
            className="flex items-center space-x-1.5 bg-emerald-500 hover:bg-emerald-400 active:scale-98 text-zinc-950 font-sans text-xs font-bold px-3.5 py-1.5 rounded transition-all cursor-pointer shadow-[0_0_12px_rgba(16,185,129,0.25)]"
          >
            <Wallet className="w-3.5 h-3.5" />
            <span>Connect Wallet</span>
          </button>
        )}
      </div>

      {/* Wallet Selector Mock Wagmi/Viem Modal Popup */}
      {showWalletModal && (
        <div className="fixed inset-0 bg-black/80 flex items-center justify-center p-4 z-50 backdrop-blur-sm">
          <div className="bg-[#090A0C] border border-zinc-800 rounded-lg w-full max-w-sm overflow-hidden p-5 animate-in zoom-in-95 duration-200 shadow-2xl">
            <div className="flex items-center justify-between pb-3.5 border-b border-zinc-900">
              <h3 className="font-display font-bold text-zinc-100 flex items-center space-x-2">
                <Shield className="w-4 h-4 text-emerald-400" />
                <span>Establish Crypto Wallet</span>
              </h3>
              <button
                onClick={() => setShowWalletModal(false)}
                className="text-zinc-500 hover:text-zinc-300 font-mono text-sm leading-none bg-zinc-900 h-6 w-6 rounded flex items-center justify-center"
              >
                ×
              </button>
            </div>

            <div className="py-4 space-y-2.5">
              <p className="text-zinc-400 text-xs font-sans pb-1.5">
                Connecting triggers safe, automated Switch Protocol with the <span className="text-emerald-400 font-semibold font-mono">Arc Testnet</span>. Select a secure web3 provider:
              </p>

              {/* MetaMask Mock Connector Option */}
              <button
                onClick={() => handleWalletSelect('metamask')}
                className="flex items-center justify-between w-full p-3 bg-[#0C0E12] border border-zinc-800 rounded hover:border-orange-500/50 hover:bg-[#12100E] text-left transition-all"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full bg-orange-950/30 flex items-center justify-center border border-orange-950">
                    <span className="text-orange-400 font-bold font-mono text-xs">M</span>
                  </div>
                  <div>
                    <span className="text-xs font-sans font-semibold text-zinc-200 block">MetaMask</span>
                    <span className="text-[10px] text-zinc-500 block font-mono">wagmi:injected:metamask</span>
                  </div>
                </div>
                <div className="text-[10px] bg-emerald-950 text-emerald-400 font-bold font-mono px-1.5 py-0.5 rounded border border-emerald-900">
                  Ready
                </div>
              </button>

              {/* OKX Mock Connector Option */}
              <button
                onClick={() => handleWalletSelect('okx')}
                className="flex items-center justify-between w-full p-3 bg-[#0C0E12] border border-zinc-800 rounded hover:border-emerald-500/50 hover:bg-[#0D120E] text-left transition-all"
              >
                <div className="flex items-center space-x-3">
                  <div className="w-8 h-8 rounded-full bg-zinc-900 flex items-center justify-center border border-zinc-800">
                    <span className="text-zinc-100 font-extrabold font-mono text-xs">OKX</span>
                  </div>
                  <div>
                    <span className="text-xs font-sans font-semibold text-zinc-200 block">OKX Wallet</span>
                    <span className="text-[10px] text-zinc-500 block font-mono">viem:eip1193:okx</span>
                  </div>
                </div>
                <div className="text-[10px] bg-emerald-950 text-emerald-400 font-bold font-mono px-1.5 py-0.5 rounded border border-emerald-900">
                  Ready
                </div>
              </button>
            </div>

            <div className="pt-2 bg-[#0C0D10] -mx-5 -mb-5 p-4 border-t border-zinc-900 flex items-center justify-between text-[11px] text-zinc-500">
              <span className="font-mono text-[10px] uppercase font-bold text-zinc-500">Auto Swapper Protocol</span>
              <span className="text-zinc-400 font-medium">ChainID: 5042002</span>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
