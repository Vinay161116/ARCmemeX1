import { useState } from 'react';
import { MemeToken, Position, WalletState, Transaction } from '../types';
import { 
  ShieldAlert, TrendingUp, TrendingDown, RefreshCcw, 
  Flame, HelpCircle, ArrowUpRight, CheckCircle2, Copy, ExternalLink 
} from 'lucide-react';

interface PortfolioTabProps {
  tokens: MemeToken[];
  wallet: WalletState;
  positions: Position[];
  transactions: Transaction[];
  closePosition: (id: string) => void;
  setActiveTab: (tab: 'trade' | 'trending' | 'portfolio' | 'watchlist' | 'ai') => void;
}

export default function PortfolioTab({
  tokens,
  wallet,
  positions,
  transactions,
  closePosition,
  setActiveTab,
}: PortfolioTabProps) {
  const [roast, setRoast] = useState<string | null>(null);
  const [roastLoading, setRoastLoading] = useState(false);
  const [copiedTxId, setCopiedTxId] = useState<string | null>(null);

  // Grab ARC Token Price
  const arcToken = tokens.find((t) => t.symbol === 'ARC');
  const arcPrice = arcToken ? arcToken.price : 1.42;

  // Calculates Net Account Values
  const walletArcVal = parseFloat(wallet.balance) * arcPrice;
  const positionsMargin = positions.reduce((sum, p) => sum + p.margin, 0);
  const totalUnrealizedPnl = positions.reduce((sum, p) => sum + p.unrealizedPnl, 0);
  const accountNetWorth = walletArcVal + positionsMargin + totalUnrealizedPnl;

  const handleRoast = async () => {
    if (positions.length === 0) {
      setRoast("🔥 Sentinel: 'You don't even have any open leverage positions. How am I supposed to roast an empty terminal? Go open a 50x leveraged long on GIGA and then come back, degen!'");
      return;
    }
    
    setRoastLoading(true);
    setRoast(null);

    try {
      const positionsSummary = positions.map(
        (p) => `${p.type} $${p.symbol} @ ${p.leverage}x Leverage, Margin $${p.margin}, P&L $${p.unrealizedPnl}`
      ).join('; ');

      const prompt = `Roast my current meme trading portfolio on Arc Testnet savage crypto twitter style. Here are my current leverage positions: ${positionsSummary}. Net Account value is $${accountNetWorth.toFixed(2)}. Make it funny, snappy, and roast my leverage sizing!`;

      const res = await fetch('/api/gemini/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: prompt, currentToken: 'PORTFOLIO' })
      });
      const data = await res.json();
      setRoast(data.text);
    } catch (e) {
      setRoast("🔥 AI Sentinel: 'Your leverage is so high, it literally short-circuited my neural network nodes. Outstanding move.'");
    } finally {
      setRoastLoading(false);
    }
  };

  const handleCopy = (hash: string, id: string) => {
    navigator.clipboard.writeText(hash);
    setCopiedTxId(id);
    setTimeout(() => setCopiedTxId(null), 1500);
  };

  return (
    <div className="p-4 max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300">
      
      {/* Account summary balances */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4">
        {/* Net account wealth */}
        <div className="bg-[#090A0C] border border-zinc-900 rounded-lg p-5 col-span-2 shadow-xl flex flex-col justify-between">
          <div>
            <span className="text-[10px] text-zinc-500 font-mono tracking-widest font-bold uppercase">Collateral Net Account Value (USD)</span>
            <h2 className="text-3xl font-display font-extrabold text-[#10B981] tracking-tight mt-1">
              ${accountNetWorth.toLocaleString([], { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </h2>
            <p className="text-[11px] text-zinc-400 mt-1 font-sans">
              Incorporating liquid wallet, active margin values, and real-time unrealized P&L stats.
            </p>
          </div>

          <div className="border-t border-zinc-900 mt-4 pt-3 flex items-center justify-between">
            <span className="text-[11px] text-zinc-500 font-mono">NET P&L REAL-TIME</span>
            <span className={`font-mono text-sm font-bold ${
              totalUnrealizedPnl >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'
            }`}>
              {totalUnrealizedPnl >= 0 ? '+$' : '-$'}{Math.abs(totalUnrealizedPnl).toFixed(2)}
            </span>
          </div>
        </div>

        {/* Free Liquid Wallet Balance */}
        <div className="bg-[#090A0C] border border-zinc-900 rounded-lg p-5 shadow-xl flex flex-col justify-between">
          <div>
            <span className="text-[10px] text-zinc-500 font-mono tracking-widest font-bold uppercase">Liquid Wallet Balance</span>
            <div className="flex items-baseline space-x-1.5 mt-1">
              <span className="text-xl font-mono font-bold text-zinc-100">
                {parseFloat(wallet.balance).toLocaleString([], { maximumFractionDigits: 2 })}
              </span>
              <span className="text-xs text-emerald-400 font-mono font-bold">ARC</span>
            </div>
            <span className="text-[11px] text-zinc-400 mt-1 block">
              Value equivalent: ~${walletArcVal.toLocaleString([], { maximumFractionDigits: 2 })} USD
            </span>
          </div>

          <div className="border-t border-zinc-900 mt-4 pt-3 flex justify-between text-[11px]">
            <span className="text-zinc-500 font-mono">CHAIN ID</span>
            <span className="text-[#3B82F6] font-semibold font-mono">5042002 (Arc)</span>
          </div>
        </div>

        {/* Active margins locked */}
        <div className="bg-[#090A0C] border border-zinc-900 rounded-lg p-5 shadow-xl flex flex-col justify-between">
          <div>
            <span className="text-[10px] text-zinc-500 font-mono tracking-widest font-bold uppercase">Active Maintenance Margin</span>
            <div className="text-xl font-mono font-bold text-zinc-200 mt-1">
              ${positionsMargin.toLocaleString([], { minimumFractionDigits: 2 })}
            </div>
            <span className="text-[11px] text-zinc-500 block mt-1 leading-tight">
              Safety deposit backing {positions.length} active positions.
            </span>
          </div>

          <div className="border-t border-zinc-900 mt-4 pt-3 flex justify-between text-[11px]">
            <span className="text-zinc-500 font-mono">POSITIONS COUNT</span>
            <span className="text-zinc-300 font-mono font-bold">{positions.length} active</span>
          </div>
        </div>
      </div>

      {/* Savage Portfolio AI Roast Panel */}
      <div className="bg-[#120B0C] border border-rose-950/20 rounded-lg p-5 shadow-xl space-y-3 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div className="flex items-center space-x-3">
            <div className="p-2.5 rounded bg-rose-950/40 border border-rose-900/30 text-rose-400">
              <Flame className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h4 className="font-display font-bold text-zinc-100 text-sm">ArcMemeX AI Portfolio Roast Office</h4>
              <p className="text-xs text-zinc-400 font-sans mt-0.5">Let Sentinel analyze your active risk profile and roast your leverage setups.</p>
            </div>
          </div>

          <button
            onClick={handleRoast}
            disabled={roastLoading}
            className="flex items-center justify-center space-x-2 bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-400 hover:to-orange-400 text-zinc-950 font-sans text-xs font-bold px-4 py-2 rounded transition-all disabled:opacity-50 cursor-pointer shadow-[0_0_12px_rgba(239,68,68,0.3)] shrink-0 self-start sm:self-center"
          >
            {roastLoading ? (
              <>
                <RefreshCcw className="w-3.5 h-3.5 animate-spin" />
                <span>Triggering Roast Oracle...</span>
              </>
            ) : (
              <>
                <Flame className="w-3.5 h-3.5" />
                <span>Roast My Trades</span>
              </>
            )}
          </button>
        </div>

        {/* Display roast text */}
        {roast && (
          <div className="bg-[#0C0708] border border-rose-950 px-4 py-3 rounded text-xs font-mono text-zinc-200 mt-2.5 leading-relaxed relative animate-in fade-in-20">
            <span className="absolute -top-1.5 left-4 text-[9px] font-bold bg-[#EF4444] text-zinc-950 uppercase px-1 rounded">Sentinel Response</span>
            <p className="whitespace-pre-line mt-1">{roast}</p>
          </div>
        )}
      </div>

      {/* Positions Ledger board */}
      <div className="bg-[#090A0C] border border-zinc-900 rounded-lg shadow-2xl p-5 space-y-4">
        <div>
          <h3 className="font-display font-semibold text-zinc-100 text-sm">Active Collateral Positions</h3>
          <p className="text-xs text-zinc-500 font-sans mt-0.5">Cross-margin leveraged meme futures listed on Arc Testnet.</p>
        </div>

        {positions.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs text-zinc-400 select-none">
              <thead>
                <tr className="border-b border-zinc-900 text-zinc-500 uppercase tracking-wider text-[9px] font-bold pb-2">
                  <th className="py-2 px-3">Liquidation Position</th>
                  <th className="py-2 px-3 text-right">Leverage Size</th>
                  <th className="py-2 px-3 text-right">Entry Price</th>
                  <th className="py-2 px-3 text-right">Mark Price</th>
                  <th className="py-2 px-3 text-right">Est. Liq Price</th>
                  <th className="py-2 px-3 text-right">Unrealized P&L (USD)</th>
                  <th className="py-2 px-3 text-center">Action</th>
                </tr>
              </thead>
              <tbody>
                {positions.map((pos) => {
                  const pnlIsUp = pos.unrealizedPnl >= 0;
                  const tokenSymbol = pos.symbol;
                  
                  return (
                    <tr key={pos.id} className="border-b border-zinc-900/60 hover:bg-[#0E1015]/60 transition-all font-sans">
                      <td className="py-3 px-3">
                        <div className="flex items-center space-x-2">
                          <span className={`px-1.5 py-0.5 rounded text-[10px] uppercase font-extrabold ${
                            pos.type === 'BUY' ? 'bg-emerald-950 text-emerald-400' : 'bg-rose-950/50 text-rose-400'
                          }`}>
                            {pos.type === 'BUY' ? 'LONG' : 'SHORT'}
                          </span>
                          <span className="text-sm font-bold text-zinc-100 uppercase">{tokenSymbol}</span>
                        </div>
                      </td>
                      <td className="py-3 px-3 text-right font-mono text-zinc-300">
                        <span className="text-zinc-500 text-[10px] mr-1">[{pos.leverage}x]</span>
                        ${pos.margin.toFixed(2)}
                      </td>
                      <td className="py-3 px-3 text-right font-mono text-zinc-400">
                        {pos.entryPrice >= 1 ? pos.entryPrice.toFixed(3) : pos.entryPrice.toFixed(6)}
                      </td>
                      <td className="py-3 px-3 text-right font-mono text-zinc-300">
                        {pos.indexPrice >= 1 ? pos.indexPrice.toFixed(3) : pos.indexPrice.toFixed(6)}
                      </td>
                      <td className="py-3 px-3 text-right font-mono text-amber-500/80">
                        {pos.liquidationPrice >= 1 ? pos.liquidationPrice.toFixed(3) : pos.liquidationPrice.toFixed(6)}
                      </td>
                      <td className={`py-3 px-3 text-right font-mono font-bold ${
                        pnlIsUp ? 'text-[#10B981]' : 'text-[#EF4444]'
                      }`}>
                        {pnlIsUp ? '+' : ''}{pos.unrealizedPnl.toFixed(2)} 
                        <span className="text-[10px] ml-1 font-medium font-sans block opacity-85">
                          ({((pos.unrealizedPnl / pos.margin) * 100).toFixed(1)}%)
                        </span>
                      </td>
                      <td className="py-3 px-3 text-center">
                        <button
                          onClick={() => closePosition(pos.id)}
                          className="bg-zinc-950 hover:bg-rose-900 hover:text-white hover:border-rose-700 text-rose-500 border border-rose-950 px-2.5 py-1 rounded text-xs transition-all cursor-pointer font-sans"
                        >
                          CLOSE
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="bg-[#0C0D10]/50 p-8 text-center rounded border border-zinc-900">
            <ShieldAlert className="w-8 h-8 text-zinc-600 mx-auto pb-1.5" />
            <h5 className="font-display font-medium text-zinc-400 text-sm">No Open Positions</h5>
            <p className="text-xs text-zinc-500 mt-1">Open 10x-50x maintenance leverage margins today inside the Trade Cockpit.</p>
            <button
              onClick={() => setActiveTab('trade')}
              className="mt-3.5 bg-emerald-500 hover:bg-emerald-400 text-zinc-950 text-xs font-bold px-3.5 py-1.5 rounded cursor-pointer transition-all"
            >
              Open Trade Cockpit
            </button>
          </div>
        )}
      </div>

      {/* Historical Ledger Transactions List */}
      <div className="bg-[#090A0C] border border-zinc-900 rounded-lg shadow-2xl p-5 space-y-4">
        <div>
          <h3 className="font-display font-semibold text-zinc-100 text-sm">Web3 Action Transaction Log</h3>
          <p className="text-xs text-zinc-500 font-sans mt-0.5">Live on-chain blockchain broadcast log indexing Arc testnet blocks.</p>
        </div>

        {transactions.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="w-full text-left font-mono text-xs text-zinc-400 select-none">
              <thead>
                <tr className="border-b border-zinc-900 text-zinc-500 uppercase tracking-wider text-[9px] font-bold pb-2">
                  <th className="py-2 px-3">Time</th>
                  <th className="py-2 px-3">Transaction ID/Hash</th>
                  <th className="py-2 px-3 text-center">Action</th>
                  <th className="py-2 px-3 text-right">Volume Size</th>
                  <th className="py-2 px-3 text-right">Base Rate</th>
                  <th className="py-2 px-3 text-center">Receipt</th>
                </tr>
              </thead>
              <tbody>
                {transactions.map((tx) => {
                  return (
                    <tr key={tx.id} className="border-b border-zinc-900/40 hover:bg-zinc-950/50 transition-all font-mono text-zinc-400">
                      <td className="py-3 px-3 text-zinc-500">{tx.timestamp}</td>
                      
                      {/* Truncated Hash and Copy Button */}
                      <td className="py-3 px-3 font-mono">
                        <div className="flex items-center space-x-1.5">
                          <span className="text-zinc-400 text-[11px] font-medium">{tx.hash.slice(0, 10)}...{tx.hash.slice(-8)}</span>
                          <button
                            onClick={() => handleCopy(tx.hash, tx.id)}
                            className="text-zinc-600 hover:text-zinc-300 transition-colors cursor-pointer"
                            title="Copy Transaction Hash"
                          >
                            {copiedTxId === tx.id ? (
                              <CheckCircle2 className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* Action column */}
                      <td className="py-3 px-3 text-center">
                        <span className={`inline-block px-1.5 py-0.5 rounded text-[10px] font-bold ${
                          tx.type === 'FUND' 
                            ? 'bg-blue-950 text-blue-400' 
                            : tx.type === 'BUY' 
                            ? 'bg-emerald-950 text-emerald-400' 
                            : tx.type === 'SELL' 
                            ? 'bg-rose-950 text-rose-400'
                            : 'bg-zinc-800 text-zinc-400 font-medium'
                        }`}>
                          {tx.type}
                        </span>
                      </td>

                      {/* Size amount */}
                      <td className="py-3 px-3 text-right text-zinc-350">
                        {tx.type === 'FUND' 
                          ? `+${tx.amount.toLocaleString()} ARC` 
                          : `${tx.amount.toFixed(4)} contracts`
                        }
                      </td>

                      {/* Execution Rate */}
                      <td className="py-3 px-3 text-right text-zinc-200">
                        {tx.type === 'FUND' ? '-' : `$${tx.price >= 1 ? tx.price.toFixed(3) : tx.price.toFixed(6)}`}
                      </td>

                      {/* Explorer Link */}
                      <td className="py-3 px-3 text-center">
                        <a
                          href={`https://testnet.arcscan.app/tx/${tx.hash}`}
                          target="_blank"
                          rel="noreferrer referrer"
                          className="inline-flex items-center space-x-1 px-2 py-0.5 rounded bg-zinc-900 hover:bg-zinc-850 hover:text-emerald-400 text-zinc-500 font-mono text-[10px]"
                        >
                          <span>Arcscan</span>
                          <ExternalLink className="w-2.5 h-2.5" />
                        </a>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-6 text-zinc-500 font-mono text-[11px]">
            No wallet transaction logs registered on Arc block nodes.
          </div>
        )}
      </div>

    </div>
  );
}
