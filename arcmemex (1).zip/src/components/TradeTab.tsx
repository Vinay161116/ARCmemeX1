import { useState, useEffect, useMemo, FormEvent } from 'react';
import { MemeToken, WalletState } from '../types';
import TradingChart from './TradingChart';
import { Copy, CheckCircle2, TrendingUp, TrendingDown, HelpCircle, Coins, ShieldCheck, CornerDownRight, ArrowUpRight } from 'lucide-react';

interface TradeTabProps {
  tokens: MemeToken[];
  selectedTokenSymbol: string;
  setSelectedTokenSymbol: (symbol: string) => void;
  wallet: WalletState;
  executeTrade: (
    symbol: string,
    type: 'BUY' | 'SELL',
    amountUsdc: number,
    leverage: number,
    entryPrice: number
  ) => boolean;
  runFaucet: () => void;
}

export default function TradeTab({
  tokens,
  selectedTokenSymbol,
  setSelectedTokenSymbol,
  wallet,
  executeTrade,
  runFaucet,
}: TradeTabProps) {
  const [tradeType, setTradeType] = useState<'BUY' | 'SELL'>('BUY');
  const [orderMethod, setOrderMethod] = useState<'market' | 'limit'>('market');
  const [leverage, setLeverage] = useState<number>(10);
  const [sizeUsdc, setSizeUsdc] = useState<string>('150');
  const [limitPriceInput, setLimitPriceInput] = useState<string>('');
  const [tpEnabled, setTpEnabled] = useState(false);
  const [slEnabled, setSlEnabled] = useState(false);
  const [copiedAddr, setCopiedAddr] = useState(false);
  const [tradeSuccessToast, setTradeSuccessToast] = useState<string | null>(null);

  // Timeframe choice
  const [timeframe, setTimeframe] = useState('15m');

  // Currently Active Token object
  const activeToken = useMemo(() => {
    return tokens.find((t) => t.symbol === selectedTokenSymbol) || tokens[0];
  }, [tokens, selectedTokenSymbol]);

  // Sync Limit Price field with token index on load or switch!
  useEffect(() => {
    setLimitPriceInput(activeToken.price.toString());
  }, [selectedTokenSymbol, activeToken.price]);

  // Handle address copying
  const handleCopy = () => {
    navigator.clipboard.writeText(activeToken.baseTokenAddress);
    setCopiedAddr(true);
    setTimeout(() => setCopiedAddr(false), 1500);
  };

  const handleTradeSubmit = (e: FormEvent) => {
    e.preventDefault();
    const usdcValue = parseFloat(sizeUsdc);
    if (isNaN(usdcValue) || usdcValue <= 0) {
      alert("Please specify a valid trading size in USDC.");
      return;
    }

    const priceToUse = orderMethod === 'limit' ? parseFloat(limitPriceInput) : activeToken.price;
    if (isNaN(priceToUse) || priceToUse <= 0) {
      alert("Please specify a valid limit order target price.");
      return;
    }

    const success = executeTrade(
      activeToken.symbol,
      tradeType,
      usdcValue,
      leverage,
      priceToUse
    );

    if (success) {
      setTradeSuccessToast(`Broadcasted ${tradeType} ${activeToken.symbol} (${usdcValue} USDC @ ${leverage}x) on Arc chain successfully.`);
      setTimeout(() => setTradeSuccessToast(null), 4000);
    }
  };

  const formatPrice = (p: number) => {
    if (p >= 1) return `$${p.toFixed(3)}`;
    if (p >= 0.01) return `$${p.toFixed(5)}`;
    return `$${p.toFixed(7)}`;
  };

  // Generate beautiful, dynamic live simulated order-book asks/bids around active token rate
  const orderBookData = useMemo(() => {
    const bids = [];
    const asks = [];
    const p = activeToken.price;

    for (let i = 1; i <= 6; i++) {
      // asks (above price)
      const askPremium = 1 + (i * 0.0008);
      const askPrice = parseFloat((p * askPremium).toFixed(activeToken.symbol === 'PEPEA' ? 7 : activeToken.symbol === 'GIGA' ? 5 : 3));
      const askSize = parseFloat(((100 + Math.random() * 8500) * (7 - i)).toFixed(1));
      asks.unshift({ price: askPrice, size: askSize, total: 0 });

      // bids (below price)
      const bidDiscount = 1 - (i * 0.0008);
      const bidPrice = parseFloat((p * bidDiscount).toFixed(activeToken.symbol === 'PEPEA' ? 7 : activeToken.symbol === 'GIGA' ? 5 : 3));
      const bidSize = parseFloat(((100 + Math.random() * 8500) * (7 - i)).toFixed(1));
      bids.push({ price: bidPrice, size: bidSize, total: 0 });
    }

    // Cumulative totals
    let askAccum = 0;
    asks.forEach(a => {
      askAccum += a.size;
      a.total = askAccum;
    });

    let bidAccum = 0;
    bids.forEach(b => {
      bidAccum += b.size;
      b.total = bidAccum;
    });

    const maxCumTotal = Math.max(askAccum, bidAccum, 1);

    return { bids, asks, maxCumTotal };
  }, [activeToken.price, activeToken.symbol]);

  // Sizing margins formulas for order accounting
  const calculatedMarginUsd = parseFloat(sizeUsdc) / leverage;
  const calculatedMarginArc = calculatedMarginUsd / (tokens.find(t => t.symbol === 'ARC')?.price || 1.425);
  const positionSizeContracts = parseFloat(sizeUsdc) / (orderMethod === 'limit' ? (parseFloat(limitPriceInput) || activeToken.price) : activeToken.price);

  return (
    <div className="grid grid-cols-1 xl:grid-cols-12 gap-4 max-w-7xl mx-auto p-4 select-none animate-in fade-in duration-300">
      
      {/* Toast Notification for Tx Broadcasting */}
      {tradeSuccessToast && (
        <div className="fixed bottom-6 right-6 bg-[#0A1A10] border border-emerald-500 rounded-lg p-4 shadow-2xl z-50 animate-bounce max-w-md flex items-start space-x-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <h5 className="font-display font-semibold text-zinc-100 text-xs text-emerald-400">Transaction Broadcast Success</h5>
            <p className="text-[11px] font-mono text-zinc-300 mt-1">{tradeSuccessToast}</p>
          </div>
        </div>
      )}

      {/* LEFT COLUMN (xl:3): Meme selections and description details */}
      <div className="xl:col-span-3 space-y-4">
        {/* Token selection array list */}
        <div className="bg-[#090A0C] border border-zinc-900 rounded-lg p-3 space-y-2">
          <span className="text-[10px] text-zinc-500 font-mono tracking-wider font-bold uppercase block px-1">Crypto Meme Indexes</span>
          <div className="space-y-1 max-h-[220px] xl:max-h-[300px] overflow-y-auto">
            {tokens.map((t) => {
              const active = t.symbol === selectedTokenSymbol;
              const gIsUp = t.priceChange24h >= 0;
              return (
                <button
                  key={t.symbol}
                  onClick={() => setSelectedTokenSymbol(t.symbol)}
                  className={`w-full flex items-center justify-between p-2 rounded transition-all text-left ${
                    active
                      ? 'bg-zinc-850/80 border border-emerald-500/10'
                      : 'hover:bg-zinc-950 border border-transparent'
                  }`}
                >
                  <div>
                    <div className="flex items-center space-x-1.5">
                      <span className="text-xs font-bold text-zinc-100 uppercase">{t.symbol}</span>
                      <span className="text-[9px] font-mono px-1 rounded bg-zinc-950 text-zinc-500">Pair</span>
                    </div>
                    <span className="text-[10px] text-zinc-500 truncate block max-w-[120px]">{t.name}</span>
                  </div>

                  <div className="text-right font-mono space-y-0.5">
                    <span className={`text-xs font-bold block ${active ? 'text-emerald-400' : 'text-zinc-200'}`}>
                      {formatPrice(t.price)}
                    </span>
                    <span className={`text-[9px] font-bold block ${gIsUp ? 'text-[#10B981]' : 'text-[#EF4444]'}`}>
                      {gIsUp ? '+' : ''}{t.priceChange24h.toFixed(1)}%
                    </span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected token details & base contract copy mechanics */}
        <div className="bg-[#090A0C] border border-zinc-900 rounded-lg p-4 space-y-3.5">
          <div>
            <h4 className="text-sm font-display font-medium text-zinc-100 flex items-center space-x-1.5 uppercase">
              <span>{activeToken.symbol} Profile</span>
            </h4>
            <p className="text-[11px] text-zinc-400 mt-1 leading-relaxed font-sans font-medium">
              {activeToken.description}
            </p>
          </div>

          <div className="space-y-2 border-t border-zinc-900/60 pt-3 text-[11px] font-mono">
            {/* contract Address */}
            <div className="flex justify-between items-center bg-zinc-950 px-2 py-1.5 rounded boundary-none">
              <span className="text-zinc-500 text-[10px] uppercase font-bold font-sans">CA: Address</span>
              <div className="flex items-center space-x-1">
                <span className="text-zinc-400 text-[10px] block font-mono">{activeToken.baseTokenAddress.slice(0, 6)}...{activeToken.baseTokenAddress.slice(-4)}</span>
                <button
                  onClick={handleCopy}
                  className="text-zinc-500 hover:text-zinc-300 transition-colors cursor-pointer"
                  title="Copy Token Base Address"
                >
                  {copiedAddr ? (
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                </button>
              </div>
            </div>

            {/* Locked Liquitity */}
            <div className="flex justify-between">
              <span className="text-zinc-500">Liquidity Locked:</span>
              <span className="text-purple-400 font-bold">${activeToken.liquidity.toLocaleString()}</span>
            </div>

            {/* Total Supply */}
            <div className="flex justify-between">
              <span className="text-zinc-500">Max Supply:</span>
              <span className="text-zinc-300 font-bold">{activeToken.supply.toLocaleString()}</span>
            </div>

            {/* Market Cap */}
            <div className="flex justify-between">
              <span className="text-zinc-500">Market Cap:</span>
              <span className="text-zinc-300 font-bold">${activeToken.marketCap.toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>

      {/* MIDDLE COLUMN (xl:6): Trading chart & (Order book + Tradings receipts) */}
      <div className="xl:col-span-6 space-y-4">
        
        {/* Dynamic Canvas Candlestick Chart */}
        <div className="h-[360px] md:h-[400px]">
          <TradingChart
            token={activeToken}
            activeTimeframe={timeframe}
            onTimeframeChange={setTimeframe}
          />
        </div>

        {/* Order Book & Recent Trade history split logs */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Orderbook simulated list */}
          <div className="bg-[#090A0C] border border-zinc-900 rounded-lg p-3.5 space-y-2">
            <span className="text-[10px] text-zinc-500 font-mono tracking-wider font-bold uppercase block px-1">Orderbook Depths</span>
            
            <div className="space-y-1 font-mono text-[11px] leading-none">
              
              {/* Asks (Asks above) */}
              <div className="space-y-1 pb-2 border-b border-zinc-900/60 flex flex-col justify-end">
                <div className="flex text-[9px] font-sans font-bold uppercase tracking-widest text-zinc-500 pb-1">
                  <span className="w-1/3">Price (USD)</span>
                  <span className="w-1/3 text-right">Size ({activeToken.symbol})</span>
                  <span className="w-1/3 text-right">Cumulative</span>
                </div>
                {orderBookData.asks.map((ask, idx) => {
                  const depthPercent = (ask.total / orderBookData.maxCumTotal) * 100;
                  return (
                    <div key={`ask-${idx}`} className="flex relative py-0.5">
                      <div 
                        className="absolute right-0 top-0 bottom-0 bg-red-950/25 border-r border-red-500/10 pointer-events-none transition-all"
                        style={{ width: `${depthPercent}%` }}
                      ></div>
                      <span className="w-1/3 text-rose-500 font-semibold z-10">{ask.price}</span>
                      <span className="w-1/3 text-right text-zinc-400 z-10">{ask.size.toLocaleString()}</span>
                      <span className="w-1/3 text-right text-zinc-500 z-10">{Math.round(ask.total).toLocaleString()}</span>
                    </div>
                  );
                })}
              </div>

              {/* Spread Indicator */}
              <div className="flex items-center justify-between py-1 px-1 bg-zinc-950 rounded my-1 border border-zinc-900 leading-none">
                <span className="text-[10px] text-zinc-400 font-bold block uppercase">Spread Mark</span>
                <span className="text-xs font-bold text-zinc-200 block">{formatPrice(activeToken.price)}</span>
              </div>

              {/* Bids (Bids below) */}
              <div className="space-y-1 pt-1">
                {orderBookData.bids.map((bid, idx) => {
                  const depthPercent = (bid.total / orderBookData.maxCumTotal) * 100;
                  return (
                    <div key={`bid-${idx}`} className="flex relative py-0.5">
                      <div 
                        className="absolute right-0 top-0 bottom-0 bg-emerald-950/20 border-r border-[#10B981]/15 pointer-events-none transition-all"
                        style={{ width: `${depthPercent}%` }}
                      ></div>
                      <span className="w-1/3 text-emerald-500 font-semibold z-10">{bid.price}</span>
                      <span className="w-1/3 text-right text-zinc-400 z-10">{bid.size.toLocaleString()}</span>
                      <span className="w-1/3 text-right text-zinc-500 z-10">{Math.round(bid.total).toLocaleString()}</span>
                    </div>
                  );
                })}
              </div>

            </div>
          </div>

          {/* Trade History Ledger dynamic feed ticks */}
          <div className="bg-[#090A0C] border border-zinc-900 rounded-lg p-3.5 space-y-2">
            <span className="text-[10px] text-zinc-500 font-mono tracking-wider font-bold uppercase block px-1">Live Executions Market Tickers</span>
            
            <div className="overflow-y-auto max-h-[195px] pr-1 space-y-1 font-mono text-[11px]">
              <div className="flex text-[9px] font-sans font-bold uppercase tracking-widest text-zinc-500 pb-1.5 border-b border-zinc-900/60 mb-1 leading-none">
                <span className="w-1/3">Time</span>
                <span className="w-1/3 text-right">Price</span>
                <span className="w-1/3 text-right">Amount ({activeToken.symbol})</span>
              </div>

              {activeToken.tradeHistory.map((th, idx) => {
                const colors = th.type === 'BUY' ? 'text-emerald-500' : 'text-rose-500';
                return (
                  <div key={idx} className="flex py-0.5 items-center leading-none">
                    <span className="w-1/3 text-zinc-500 text-[10px]">{th.time}</span>
                    <span className={`w-1/3 text-right font-bold ${colors}`}>{th.price}</span>
                    <span className="w-1/3 text-right text-zinc-300 font-medium">{(th.size).toLocaleString([], { maximumFractionDigits: 1 })}</span>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      </div>

      {/* RIGHT COLUMN (xl:3): Markt/Limit futures leverage margin form */}
      <div className="xl:col-span-3 space-y-4">
        
        {/* Leverage Buy Form */}
        <div className="bg-[#090A0C] border border-zinc-900 rounded-lg p-4 space-y-3.5 shadow-2xl relative select-text">
          <div className="absolute top-2.5 right-3.5 flex items-center space-x-1 text-[9px] font-mono text-zinc-600 uppercase font-bold pointer-events-none">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
            <span>Secured Order</span>
          </div>

          {/* Buy vs Sell select tab block */}
          <div className="grid grid-cols-2 p-1 bg-zinc-950 border border-zinc-900 rounded select-none">
            <button
              type="button"
              onClick={() => setTradeType('BUY')}
              className={`py-1 rounded text-xs font-bold transition-all ${
                tradeType === 'BUY'
                  ? 'bg-[#142A1E] text-[#10B981] border border-[#10B981]/25'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              LONG (BUY)
            </button>
            <button
              type="button"
              onClick={() => setTradeType('SELL')}
              className={`py-1 rounded text-xs font-bold transition-all ${
                tradeType === 'SELL'
                  ? 'bg-[#2D161A] text-[#EF4444] border border-[#EF4444]/25'
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              SHORT (SELL)
            </button>
          </div>

          {/* Market vs Limit options */}
          <div className="flex space-x-2 border-b border-zinc-900/60 pb-2 select-none">
            {['market', 'limit'].map((mtd) => (
              <button
                key={mtd}
                type="button"
                onClick={() => setOrderMethod(mtd as any)}
                className={`px-3 py-1 text-[11px] font-mono font-bold uppercase rounded ${
                  orderMethod === mtd
                    ? 'bg-zinc-900 text-zinc-200'
                    : 'text-zinc-500 hover:text-zinc-300'
                }`}
              >
                {mtd}
              </button>
            ))}
          </div>

          <form onSubmit={handleTradeSubmit} className="space-y-4 font-sans text-xs">
            {/* Sizing margin details inputs */}
            <div className="space-y-2 select-none">
              
              {/* Sizing usdc input box */}
              <div className="space-y-1">
                <div className="flex justify-between text-zinc-500 text-[10px] uppercase font-bold">
                  <span>Order Size (USDC)</span>
                  <span>Leveraged Collatoral</span>
                </div>
                <div className="relative">
                  <input
                    type="number"
                    value={sizeUsdc}
                    onChange={(e) => setSizeUsdc(e.target.value)}
                    min="10"
                    max="100000"
                    required
                    className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-zinc-200 font-mono focus:outline-none focus:border-emerald-500/55 text-xs text-right pr-12 font-bold"
                  />
                  <span className="absolute right-3 top-2.5 text-[10px] text-zinc-500 font-mono font-extrabold uppercase">USDC</span>
                </div>
              </div>

              {/* Limit targeting price if order method is Limit */}
              {orderMethod === 'limit' && (
                <div className="space-y-1 animate-in fade-induration-150">
                  <span className="text-zinc-500 text-[10px] uppercase font-bold block">Limit Rate Price</span>
                  <div className="relative">
                    <input
                      type="number"
                      step="any"
                      value={limitPriceInput}
                      onChange={(e) => setLimitPriceInput(e.target.value)}
                      required
                      className="w-full bg-zinc-950 border border-zinc-800 rounded p-2 text-zinc-200 font-mono focus:outline-none focus:border-emerald-500/55 text-xs text-right pr-12"
                    />
                    <span className="absolute right-3 top-2.5 text-[10px] text-zinc-500 font-mono">USD</span>
                  </div>
                </div>
              )}

              {/* Leverage Slider block bar */}
              <div className="space-y-1.5 pt-1">
                <div className="flex justify-between items-center text-zinc-500 text-[10px] uppercase font-bold">
                  <span>Active Cross Leverage</span>
                  <span className="text-orange-400 font-mono font-extrabold bg-[#231A12] px-1.5 py-0.5 rounded border border-[#orange]/5 border-orange-950 text-[10px]">{leverage}x Size</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="50"
                  step="1"
                  value={leverage}
                  onChange={(e) => setLeverage(parseInt(e.target.value))}
                  className="w-full text-emerald-500 accent-emerald-500 cursor-pointer h-1 bg-zinc-950 rounded bg-zinc-900 border border-zinc-950"
                />
                <div className="flex justify-between text-[9px] font-mono text-zinc-600">
                  <span>1x Spot</span>
                  <span>10x Med</span>
                  <span>25x High</span>
                  <span className="text-rose-500">50x DEGEN</span>
                </div>
              </div>
            </div>

            {/* Checkbox triggers for Stop loss and TP */}
            <div className="space-y-1.5 select-none text-[11px] font-semibold text-zinc-500 border-t border-zinc-900/60 pt-3">
              <label className="flex items-center space-x-2 cursor-pointer hover:text-zinc-300 transition-colors">
                <input
                  type="checkbox"
                  checked={tpEnabled}
                  onChange={(e) => setTpEnabled(e.target.checked)}
                  className="rounded text-emerald-500 accent-emerald-500 focus:ring-0 focus:outline-none focus:border-zinc-800"
                />
                <span>Enable Take Profit (TP) target</span>
              </label>

              <label className="flex items-center space-x-2 cursor-pointer hover:text-zinc-300 transition-colors">
                <input
                  type="checkbox"
                  checked={slEnabled}
                  onChange={(e) => setSlEnabled(e.target.checked)}
                  className="rounded text-rose-500 accent-rose-500 focus:ring-0 focus:outline-none"
                />
                <span>Enable Stop Loss (SL) barrier</span>
              </label>
            </div>

            {/* Sizing Accounting formulas displays */}
            <div className="bg-zinc-950/80 p-3 rounded space-y-1.5 text-[10.5px] font-mono text-zinc-500 leading-tight">
              <div className="flex justify-between">
                <span>Total Leverage size:</span>
                <span className="text-zinc-300">${parseFloat(sizeUsdc || '0').toLocaleString()} USDC</span>
              </div>
              <div className="flex justify-between">
                <span>Contracts volume:</span>
                <span className="text-zinc-300 text-right">{positionSizeContracts.toFixed(4)} {activeToken.symbol}</span>
              </div>
              <div className="flex justify-between border-t border-zinc-900/60 pt-1.5 mt-1.5 font-sans font-bold">
                <span className="uppercase text-[9.5px]">Required Margin Collateral:</span>
                <span className="text-emerald-400 font-mono">${calculatedMarginUsd.toFixed(2)} USD (~{calculatedMarginArc.toFixed(2)} ARC)</span>
              </div>
              <div className="flex justify-between text-[9px] text-zinc-600">
                <span>Est Gas GasFee:</span>
                <span>~ 0.001 ARC ($0.0015)</span>
              </div>
            </div>

            {/* Sizing submit action */}
            {wallet.isConnected ? (
              <button
                type="submit"
                className={`w-full py-2.5 rounded font-sans font-bold text-sm tracking-tight transition-all active:scale-98 cursor-pointer select-none ${
                  tradeType === 'BUY'
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-zinc-950 hover:from-emerald-400 hover:to-teal-500 shadow-[0_0_12px_rgba(16,185,129,0.2)]'
                    : 'bg-gradient-to-r from-rose-500 to-red-650 text-white hover:from-rose-400 hover:to-red-550 shadow-[0_0_12px_rgba(239,68,68,0.2)]'
                }`}
              >
                BROADCAST {tradeType === 'BUY' ? 'LONG' : 'SHORT'} ORDER
              </button>
            ) : (
              <div className="p-3 bg-zinc-950 rounded text-center border border-zinc-900 select-none">
                <span className="text-zinc-500 block leading-tight font-sans text-[11px]">Metamask / OKX connector status offline.</span>
                <span className="text-[10px] text-zinc-600 font-mono block mt-0.5">Auto connection switched to ETH default.</span>
              </div>
            )}
          </form>
        </div>

        {/* Free ARC Faucet container */}
        <div className="bg-[#090A0C] border border-zinc-900 rounded-lg p-4 space-y-3 shadow-xl">
          <div className="flex items-center space-x-2 text-zinc-100">
            <Coins className="w-4 h-4 text-emerald-400" />
            <h5 className="font-display font-semibold text-xs tracking-tight uppercase">Arc Free Testnet Faucet</h5>
          </div>
          
          <p className="text-[11px] text-zinc-500 leading-normal font-sans">
            Need gas or trade collateral? Grab <span className="text-emerald-400 font-semibold font-mono">500.00 ARC</span> testnet faucet tokens instantly to run leverage triggers.
          </p>

          <button
            onClick={runFaucet}
            disabled={!wallet.isConnected}
            className="w-full flex items-center justify-center space-x-1.5 py-1.5 block bg-zinc-900 font-sans font-bold hover:bg-emerald-500 hover:text-zinc-950 text-emerald-500 border border-emerald-500/10 hover:border-emerald-500/35 text-[11px] rounded transition-all disabled:opacity-35 disabled:cursor-not-allowed select-none cursor-pointer"
          >
            <Coins className="w-3.5 h-3.5" />
            <span>Fund Wallet +500 ARC</span>
          </button>
        </div>
      </div>

    </div>
  );
}
