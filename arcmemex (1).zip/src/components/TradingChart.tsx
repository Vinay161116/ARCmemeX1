import { useState, useRef, useEffect, MouseEvent } from 'react';
import { MemeToken } from '../types';

interface TradingChartProps {
  token: MemeToken;
  activeTimeframe: string;
  onTimeframeChange: (tf: string) => void;
}

export default function TradingChart({ token, activeTimeframe, onTimeframeChange }: TradingChartProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState({ width: 600, height: 350 });
  const [hoveredCandle, setHoveredCandle] = useState<any | null>(null);
  const [hoverPosition, setHoverPosition] = useState<{ x: number; y: number } | null>(null);

  // Monitor container width to keep SVG fluid and auto-scaling
  useEffect(() => {
    if (!containerRef.current) return;
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect;
        setDimensions({
          width: Math.max(width, 300),
          height: Math.max(height, 250),
        });
      }
    });
    resizeObserver.observe(containerRef.current);
    return () => resizeObserver.disconnect();
  }, []);

  const { width, height } = dimensions;
  const paddingRight = 60;
  const paddingBottom = 30;
  const paddingTop = 20;
  const paddingLeft = 10;

  const chartWidth = width - paddingLeft - paddingRight;
  const chartHeight = height - paddingTop - paddingBottom;

  // Use the last 35 candles for display
  const displayCandles = token.candles.slice(-35);

  if (displayCandles.length === 0) {
    return (
      <div className="h-[350px] flex items-center justify-center text-zinc-500 font-mono text-sm bg-zinc-950 border border-zinc-900 rounded-lg">
        No dynamic candle telemetry loaded
      </div>
    );
  }

  // Find min and max for scaling
  const prices = displayCandles.flatMap((c) => [c.high, c.low, c.open, c.close]);
  const minPrice = Math.min(...prices) * 0.995;
  const maxPrice = Math.max(...prices) * 1.005;
  const priceRange = maxPrice - minPrice;

  const maxVolume = Math.max(...displayCandles.map((c) => c.volume), 1);

  // Scaling helpers
  const getX = (index: number) => {
    return paddingLeft + (index / (displayCandles.length - 1)) * chartWidth;
  };

  const getY = (price: number) => {
    return paddingTop + chartHeight - ((price - minPrice) / priceRange) * chartHeight;
  };

  const getVolHeight = (volume: number) => {
    // Volume bars occupy bottom 15% of chart
    return (volume / maxVolume) * (chartHeight * 0.18);
  };

  // Generate an elegant golden SMA (Simple Moving Average - 9 periods)
  const smaPoints: Array<{ x: number; y: number }> = [];
  for (let i = 0; i < displayCandles.length; i++) {
    if (i >= 8) {
      let sum = 0;
      for (let j = 0; j < 9; j++) {
        sum += displayCandles[i - j].close;
      }
      const avg = sum / 9;
      smaPoints.push({ x: getX(i), y: getY(avg) });
    }
  }

  const smaPath = smaPoints.length > 0
    ? `M ${smaPoints.map((p) => `${p.x},${p.y}`).join(' L ')}`
    : '';

  // Grid line coordinates
  const gridLinesCount = 5;
  const gridLines = Array.from({ length: gridLinesCount }).map((_, i) => {
    const val = minPrice + (priceRange * i) / (gridLinesCount - 1);
    return {
      price: val,
      y: getY(val),
    };
  });

  const handleMouseMove = (e: MouseEvent<SVGSVGElement>) => {
    if (!containerRef.current) return;
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left - paddingLeft;
    
    // Find nearest candle
    const index = Math.round((x / chartWidth) * (displayCandles.length - 1));
    if (index >= 0 && index < displayCandles.length) {
      setHoveredCandle(displayCandles[index]);
      setHoverPosition({
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      });
    }
  };

  const handleMouseLeave = () => {
    setHoveredCandle(null);
    setHoverPosition(null);
  };

  const formatPriceLabel = (p: number) => {
    if (p >= 1) return p.toFixed(2);
    if (p >= 0.01) return p.toFixed(4);
    return p.toFixed(6);
  };

  return (
    <div className="flex flex-col h-full bg-[#090A0C] border border-zinc-900 rounded-lg overflow-hidden select-none">
      {/* Chart Headers */}
      <div className="flex flex-wrap items-center justify-between border-b border-zinc-900 px-4 py-2 bg-[#0C0D10]/80">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2">
            <span className="text-sm font-semibold text-zinc-100 font-sans tracking-tight">{token.symbol}/USD</span>
            <span className="text-[11px] font-mono font-medium px-1.5 py-0.5 rounded bg-zinc-900 border border-zinc-800 text-zinc-400">
              9-EMA
            </span>
          </div>
          
          {hoveredCandle ? (
            <div className="hidden sm:flex items-center space-x-3 text-[11px] font-mono text-zinc-400">
              <span>O:<span style={{ color: hoveredCandle.close >= hoveredCandle.open ? '#10B981' : '#EF4444' }}>{formatPriceLabel(hoveredCandle.open)}</span></span>
              <span>H:<span className="text-zinc-200">{formatPriceLabel(hoveredCandle.high)}</span></span>
              <span>L:<span className="text-zinc-200">{formatPriceLabel(hoveredCandle.low)}</span></span>
              <span>C:<span style={{ color: hoveredCandle.close >= hoveredCandle.open ? '#10B981' : '#EF4444' }}>{formatPriceLabel(hoveredCandle.close)}</span></span>
              <span className="text-zinc-500">Vol:{hoveredCandle.volume.toLocaleString()}</span>
            </div>
          ) : (
            <div className="hidden sm:flex items-center space-x-3 text-[11px] font-mono text-zinc-500">
              <span>Hover canvas for precise tick data</span>
            </div>
          )}
        </div>

        {/* Timeframes Selector */}
        <div className="flex space-x-1">
          {['1m', '5m', '15m', '1h', '4h', '1D'].map((tf) => (
            <button
              key={tf}
              onClick={() => onTimeframeChange(tf)}
              className={`px-2 py-0.5 rounded text-xs font-mono font-bold transition-all ${
                activeTimeframe === tf
                  ? 'bg-zinc-800 text-emerald-400 border border-emerald-500/20'
                  : 'text-zinc-500 hover:text-zinc-300 hover:bg-zinc-900'
              }`}
            >
              {tf}
            </button>
          ))}
        </div>
      </div>

      {/* SVG Canvas Container */}
      <div ref={containerRef} className="relative flex-1 bg-[#090A0C] min-h-[220px]">
        <svg
          width="100%"
          height="100%"
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          className="absolute inset-0 cursor-crosshair overflow-visible"
        >
          {/* Price Grid Lines & Labels */}
          {gridLines.map((line, i) => (
            <g key={i}>
              <line
                x1={paddingLeft}
                y1={line.y}
                x2={width - paddingRight}
                y2={line.y}
                stroke="#16181D"
                strokeWidth={1}
                strokeDasharray="2,3"
              />
              <text
                x={width - paddingRight + 5}
                y={line.y + 3}
                fill="#52525B"
                fontSize={10}
                fontFamily="inherit"
                className="font-mono text-right"
              >
                {formatPriceLabel(line.price)}
              </text>
            </g>
          ))}

          {/* Vertical Separators */}
          {displayCandles.map((c, i) => {
            if (i % 7 === 0) {
              const xPos = getX(i);
              return (
                <g key={i}>
                  <line
                    x1={xPos}
                    y1={paddingTop}
                    x2={xPos}
                    y2={height - paddingBottom}
                    stroke="#16181D"
                    strokeWidth={1}
                  />
                  <text
                    x={xPos}
                    y={height - paddingBottom + 15}
                    fill="#52525B"
                    fontSize={9}
                    fontFamily="inherit"
                    textAnchor="middle"
                    className="font-mono"
                  >
                    {c.time}
                  </text>
                </g>
              );
            }
            return null;
          })}

          {/* Volume bars (Bottom 18%) */}
          {displayCandles.map((c, i) => {
            const x = getX(i);
            const vHeight = getVolHeight(c.volume);
            const isUp = c.close >= c.open;
            
            return (
              <rect
                key={`vol-${i}`}
                x={x - 2}
                y={height - paddingBottom - vHeight}
                width={4}
                height={vHeight}
                fill={isUp ? '#10B981' : '#EF4444'}
                fillOpacity={0.15}
              />
            );
          })}

          {/* Technical Indicator Gold SMA Path */}
          {smaPath && (
            <path
              d={smaPath}
              fill="none"
              stroke="#F59E0B"
              strokeWidth={1.5}
              strokeOpacity={0.75}
            />
          )}

          {/* Candlestick Glyphs */}
          {displayCandles.map((c, i) => {
            const x = getX(i);
            const yOpen = getY(c.open);
            const yClose = getY(c.close);
            const yHigh = getY(c.high);
            const yLow = getY(c.low);
            const isUp = c.close >= c.open;

            const candleColor = isUp ? '#10B981' : '#EF4444';
            const rectY = Math.min(yOpen, yClose);
            const rectH = Math.max(Math.abs(yOpen - yClose), 1.5);

            return (
              <g key={`candle-${i}`}>
                {/* Wick */}
                <line
                  x1={x}
                  y1={yHigh}
                  x2={x}
                  y2={yLow}
                  stroke={candleColor}
                  strokeWidth={1.2}
                />
                {/* Body */}
                <rect
                  x={x - 3}
                  y={rectY}
                  width={6}
                  height={rectH}
                  fill={candleColor}
                  stroke={candleColor}
                  strokeWidth={0.5}
                  rx={0.5}
                />
              </g>
            );
          })}

          {/* Crosshair guidelines on hover */}
          {hoverPosition && (
            <g>
              {/* Vertical line */}
              <line
                x1={hoverPosition.x}
                y1={paddingTop}
                x2={hoverPosition.x}
                y2={height - paddingBottom}
                stroke="#3F3F46"
                strokeWidth={0.5}
                strokeDasharray="4,4"
              />
              {/* Horizontal line */}
              <line
                x1={paddingLeft}
                y1={hoverPosition.y}
                x2={width - paddingRight}
                y2={hoverPosition.y}
                stroke="#3F3F46"
                strokeWidth={0.5}
                strokeDasharray="4,4"
              />
              {/* Hover Node indicator */}
              <circle
                cx={hoverPosition.x}
                cy={hoverPosition.y}
                r={3}
                fill="#3B82F6"
                stroke="#FFFFFF"
                strokeWidth={1}
              />
            </g>
          )}
        </svg>

        {/* Real-time price tag float */}
        <div 
          className="absolute right-[65px] flex items-center bg-zinc-900 border border-zinc-800 text-[10px] text-zinc-400 font-mono px-1.5 py-0.5 rounded pointer-events-none"
          style={{ top: `${Math.min(Math.max(getY(token.price) - 10, paddingTop), height - paddingBottom - 20)}px` }}
        >
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block mr-1 animate-pulse"></span>
          {formatPriceLabel(token.price)}
        </div>
      </div>
    </div>
  );
}
