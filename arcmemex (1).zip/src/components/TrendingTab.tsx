import { useState } from 'react';
import { MemeToken } from '../types';
import { Search, TrendingUp, Sparkles, Star, ChevronRight, Activity, ArrowUpDown } from 'lucide-react';

interface TrendingTabProps {
  tokens: MemeToken[];
  watchlist: string[];
  toggleWatchlist: (symbol: string) => void;
  onSelectToken: (symbol: string) => void;
  setActiveTab: (tab: 'trade' | 'trending' | 'portfolio' | 'watchlist' | 'ai') => void;
}

type SortField = 'price' | 'change' | 'volume' | 'liquidity' | 'mcap';

export default function TrendingTab({
  tokens,
  watchlist,
  toggleWatchlist,
  onSelectToken,
  setActiveTab,
}: TrendingTabProps) {
  const [search, setSearch] = useState('');
  const [sortField, setSortField] = useState<SortField>('volume');
  const [sortAsc, setSortAsc] = useState(false);

  const formatPrice = (p: number) => {
    if (p >= 1) return `$${p.toFixed(3)}`;
    if (p >= 0.01) return `$${p.toFixed(5)}`;
    return `$${p.toFixed(7)}`;
  };

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(false);
    }
  };

  // Filter & Sort core tokens
  const filteredTokens = tokens.filter(
    (t) =>
      t.symbol.toLowerCase().includes(search.toLowerCase()) ||
      t.name.toLowerCase().includes(search.toLowerCase())
  );

  const sortedTokens = [...filteredTokens].sort((a, b) => {
    let valA = 0;
    let valB = 0;

    switch (sortField) {
      case 'price':
        valA = a.price;
        valB = b.price;
        break;
      case 'change':
        valA = a.priceChange24h;
        valB = b.priceChange24h;
        break;
      case 'volume':
        valA = a.volume24h;
        valB = b.volume24h;
        break;
      case 'liquidity':
        valA = a.liquidity;
        valB = b.liquidity;
        break;
      case 'mcap':
        valA = a.marketCap;
        valB = b.marketCap;
        break;
    }

    return sortAsc ? valA - valB : valB - valA;
  });

  // Highlight gems
  const topGainer = [...tokens].sort((a, b) => b.priceChange24h - a.priceChange24h)[0];
  const topVolume = [...tokens].sort((a, b) => b.volume24h - a.volume24h)[0];
  const hotGem = [...tokens].sort((a, b) => (b.liquidity / b.marketCap) - (a.liquidity / a.marketCap))[0];

  return (
    <div className="p-4 space-y-6 max-w-7xl mx-auto animate-in fade-in duration-300">
      
      {/* Top Spotlights Banner Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Top Gainer */}
        <div className="bg-gradient-to-br from-[#0C1E14] to-[#080E0A] border border-emerald-900/30 rounded-lg p-4 flex items-center justify-between shadow-xl relative overflow-hidden">
          <div className="space-y-1">
            <div className="flex items-center space-x-1.5 text-emerald-400 font-mono text-xs font-bold uppercase tracking-wider">
              <TrendingUp className="w-3.5 h-3.5" />
              <span>Top 24h Gainer</span>
            </div>
            <h4 className="text-xl font-bold text-zinc-100 font-display">{topGainer.name}</h4>
            <div className="flex items-center space-x-2 text-sm font-mono mt-1">
              <span className="text-[#10B981] font-bold">+{topGainer.priceChange24h.toFixed(1)}%</span>
              <span className="text-zinc-500">•</span>
              <span className="text-zinc-300">{formatPrice(topGainer.price)}</span>
            </div>
          </div>
          <button
            onClick={() => {
              onSelectToken(topGainer.symbol);
              setActiveTab('trade');
            }}
            className="flex items-center justify-center h-8 w-8 rounded-full bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold hover:scale-105 transition-all cursor-pointer"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Volume Leader */}
        <div className="bg-gradient-to-br from-[#10192A] to-[#080E16] border border-[#1E293B]/30 rounded-lg p-4 flex items-center justify-between shadow-xl relative overflow-hidden">
          <div className="space-y-1">
            <div className="flex items-center space-x-1.5 text-blue-400 font-mono text-xs font-bold uppercase tracking-wider">
              <Activity className="w-3.5 h-3.5" />
              <span>Volume Leader</span>
            </div>
            <h4 className="text-xl font-bold text-zinc-100 font-display">{topVolume.name}</h4>
            <div className="flex items-center space-x-2 text-sm font-mono mt-1">
              <span className="text-blue-400 font-semibold">${topVolume.volume24h.toLocaleString()}</span>
              <span className="text-zinc-500">•</span>
              <span className="text-zinc-300">{formatPrice(topVolume.price)}</span>
            </div>
          </div>
          <button
            onClick={() => {
              onSelectToken(topVolume.symbol);
              setActiveTab('trade');
            }}
            className="flex items-center justify-center h-8 w-8 rounded-full bg-[#3B82F6] hover:bg-blue-400 text-zinc-950 font-bold hover:scale-105 transition-all cursor-pointer"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Hot Liquidity Pool */}
        <div className="bg-gradient-to-br from-[#1C171E] to-[#0A070B] border border-purple-900/30 rounded-lg p-4 flex items-center justify-between shadow-xl relative overflow-hidden">
          <div className="space-y-1">
            <div className="flex items-center space-x-1.5 text-purple-400 font-mono text-xs font-bold uppercase tracking-wider">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Deep Liquidity</span>
            </div>
            <h4 className="text-xl font-bold text-zinc-100 font-display">{hotGem.name}</h4>
            <div className="flex items-center space-x-2 text-sm font-mono mt-1">
              <span className="text-purple-400 font-semibold">${hotGem.liquidity.toLocaleString()} Pool</span>
              <span className="text-zinc-500">•</span>
              <span className="text-zinc-300">{formatPrice(hotGem.price)}</span>
            </div>
          </div>
          <button
            onClick={() => {
              onSelectToken(hotGem.symbol);
              setActiveTab('trade');
            }}
            className="flex items-center justify-center h-8 w-8 rounded-full bg-purple-500 hover:bg-purple-400 text-zinc-950 font-bold hover:scale-105 transition-all cursor-pointer"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Stats Display Filters */}
      <div className="bg-[#090A0C] border border-zinc-900 rounded-lg shadow-2xl p-5 space-y-4">
        
        {/* Tab Controls headers */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3.5 pb-2">
          <div>
            <h3 className="font-display font-semibold text-base text-zinc-100">Live ArcMemeX Ticker Board</h3>
            <p className="text-xs text-zinc-500 font-sans mt-0.5">DexScreener styled index sorting all trading gems instantly.</p>
          </div>

          {/* Search container */}
          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-2.5 w-3.5 h-3.5 text-zinc-500" />
            <input
              type="text"
              placeholder="Search symbol or contract address..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-4 py-1.5 rounded bg-zinc-950 border border-zinc-800 text-xs font-sans text-zinc-300 placeholder-zinc-600 focus:outline-none focus:border-emerald-500/50"
            />
          </div>
        </div>

        {/* Token Dense Data listing columns */}
        <div className="overflow-x-auto">
          <table className="w-full text-left font-mono text-xs text-zinc-400 select-none border-collapse">
            <thead>
              <tr className="border-b border-zinc-900 text-zinc-500 uppercase tracking-widest text-[9px] font-bold">
                <th className="py-2.5 px-3">Gem Token</th>
                <th 
                  className="py-2.5 px-3 text-right cursor-pointer hover:text-zinc-300"
                  onClick={() => handleSort('price')}
                >
                  <div className="flex items-center justify-end space-x-1">
                    <span>Price</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th 
                  className="py-2.5 px-3 text-right cursor-pointer hover:text-zinc-300"
                  onClick={() => handleSort('change')}
                >
                  <div className="flex items-center justify-end space-x-1">
                    <span>24h Change</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th 
                  className="py-2.5 px-3 text-right cursor-pointer hover:text-zinc-300"
                  onClick={() => handleSort('volume')}
                >
                  <div className="flex items-center justify-end space-x-1">
                    <span>Volume 24h</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th 
                  className="py-2.5 px-3 text-right cursor-pointer hover:text-zinc-300"
                  onClick={() => handleSort('liquidity')}
                >
                  <div className="flex items-center justify-end space-x-1">
                    <span>Liquidity</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th 
                  className="py-2.5 px-3 text-right cursor-pointer hover:text-zinc-300"
                  onClick={() => handleSort('mcap')}
                >
                  <div className="flex items-center justify-end space-x-1">
                    <span>Mkt Cap</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="py-2.5 px-3 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {sortedTokens.length > 0 ? (
                sortedTokens.map((t) => {
                  const changeIsUp = t.priceChange24h >= 0;
                  const isWatch = watchlist.includes(t.symbol);
                  
                  return (
                    <tr 
                      key={t.symbol} 
                      className="border-b border-zinc-900/55 hover:bg-[#0E1015]/60 transition-all group font-sans"
                    >
                      {/* Name Card */}
                      <td className="py-3 px-3">
                        <div className="flex items-center space-x-3">
                          <button
                            onClick={() => toggleWatchlist(t.symbol)}
                            className="text-zinc-600 hover:text-yellow-400 transition-colors"
                          >
                            <Star className={`w-4 h-4 ${isWatch ? 'fill-yellow-400 text-yellow-400' : ''}`} />
                          </button>
                          
                          <div>
                            <div className="flex items-center space-x-1.5">
                              <span className="text-sm font-bold text-zinc-100 group-hover:text-emerald-400 transition-colors">
                                {t.symbol}
                              </span>
                              <span className="text-[9px] font-mono font-medium text-zinc-500 bg-zinc-950 border border-zinc-900 px-1 rounded uppercase">
                                Pair: {t.symbol}/USD
                              </span>
                            </div>
                            <span className="text-xs text-zinc-400 block mt-0.5">{t.name}</span>
                          </div>
                        </div>
                      </td>

                      {/* Price column */}
                      <td className="py-3 px-3 text-right font-mono font-semibold text-zinc-200">
                        {formatPrice(t.price)}
                      </td>

                      {/* 24h change column */}
                      <td className="py-3 px-3 text-right font-mono">
                        <span className={`inline-block px-1.5 py-0.5 rounded text-[11px] font-semibold ${
                          changeIsUp ? 'bg-emerald-950/40 text-emerald-400' : 'bg-rose-950/40 text-rose-400'
                        }`}>
                          {changeIsUp ? '+' : ''}{t.priceChange24h.toFixed(2)}%
                        </span>
                      </td>

                      {/* Volume column */}
                      <td className="py-3 px-3 text-right font-mono text-zinc-300">
                        ${t.volume24h.toLocaleString()}
                      </td>

                      {/* Liquidity column */}
                      <td className="py-3 px-3 text-right font-mono text-zinc-300">
                        ${t.liquidity.toLocaleString()}
                      </td>

                      {/* Market Cap */}
                      <td className="py-3 px-3 text-right font-mono text-zinc-300">
                        ${t.marketCap.toLocaleString()}
                      </td>

                      {/* Actions */}
                      <td className="py-3 px-3 text-center">
                        <button
                          onClick={() => {
                            onSelectToken(t.symbol);
                            setActiveTab('trade');
                          }}
                          className="bg-zinc-900 hover:bg-emerald-500 hover:text-zinc-950 text-emerald-400 border border-emerald-500/20 px-3 py-1 rounded text-xs font-semibold font-sans pointer-events-auto transition-all active:scale-95 cursor-pointer"
                        >
                          TRADE
                        </button>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={7} className="text-center py-8 text-zinc-500 font-mono">
                    No matching meme gems found
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
