import { MemeToken } from '../types';
import { Star, ShieldAlert, ArrowUpRight, TrendingUp, TrendingDown } from 'lucide-react';

interface WatchlistTabProps {
  tokens: MemeToken[];
  watchlist: string[];
  toggleWatchlist: (symbol: string) => void;
  onSelectToken: (symbol: string) => void;
  setActiveTab: (tab: 'trade' | 'trending' | 'portfolio' | 'watchlist' | 'ai') => void;
}

export default function WatchlistTab({
  tokens,
  watchlist,
  toggleWatchlist,
  onSelectToken,
  setActiveTab,
}: WatchlistTabProps) {
  
  const formatPrice = (p: number) => {
    if (p >= 1) return `$${p.toFixed(3)}`;
    if (p >= 0.01) return `$${p.toFixed(5)}`;
    return `$${p.toFixed(7)}`;
  };

  const watchlistedTokens = tokens.filter((t) => watchlist.includes(t.symbol));

  return (
    <div className="p-4 max-w-7xl mx-auto space-y-6 animate-in fade-in duration-300">
      <div>
        <h3 className="font-display font-semibold text-lg text-zinc-100 flex items-center space-x-2">
          <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
          <span>My Terminal Watchlist</span>
        </h3>
        <p className="text-xs text-zinc-500 font-sans mt-0.5">Quick lookup board monitoring selected favorites on Arc Testnet.</p>
      </div>

      {watchlistedTokens.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {watchlistedTokens.map((t) => {
            const isUp = t.priceChange24h >= 0;
            return (
              <div 
                key={t.symbol} 
                className="bg-[#090A0C] border border-zinc-900 rounded-lg p-5 flex flex-col justify-between hover:border-zinc-800 transition-all group shadow-xl"
              >
                <div>
                  <div className="flex items-center justify-between pb-3 border-b border-zinc-900">
                    <div className="flex items-center space-x-2">
                      <span className="text-base font-bold text-zinc-100 group-hover:text-emerald-400 transition-colors uppercase">
                        {t.symbol}
                      </span>
                      <span className="text-[10px] text-zinc-400 font-sans font-medium px-1 rounded bg-zinc-950 border border-zinc-900">USD</span>
                    </div>

                    <button 
                      onClick={() => toggleWatchlist(t.symbol)}
                      className="text-yellow-400 hover:text-zinc-600 transition-colors"
                    >
                      <Star className="w-4 h-4 fill-yellow-400" />
                    </button>
                  </div>

                  <p className="text-xs text-zinc-500 font-sans mt-2 line-clamp-1">
                    {t.description}
                  </p>

                  <div className="flex items-end justify-between mt-4">
                    <div className="space-y-0.5">
                      <span className="text-[11px] text-zinc-500 block">LAST INDEX PRICE</span>
                      <span className="text-lg font-mono font-bold text-zinc-100">
                        {formatPrice(t.price)}
                      </span>
                    </div>

                    <div className="text-right space-y-1">
                      <span className="text-[10px] text-zinc-500 block">24H GAINS</span>
                      <span className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded text-xs font-mono font-bold ${
                        isUp ? 'bg-emerald-950/40 text-emerald-400' : 'bg-rose-950/40 text-rose-400'
                      }`}>
                        {isUp ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                        <span>{isUp ? '+' : ''}{t.priceChange24h.toFixed(2)}%</span>
                      </span>
                    </div>
                  </div>
                </div>

                <div className="border-t border-zinc-900/60 mt-5 pt-3.5 flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="text-[10px] text-zinc-500 block">24H VOLUME</span>
                    <span className="text-xs font-mono font-medium text-zinc-300">
                      ${t.volume24h.toLocaleString()}
                    </span>
                  </div>

                  <button
                    onClick={() => {
                      onSelectToken(t.symbol);
                      setActiveTab('trade');
                    }}
                    className="flex items-center space-x-1.5 bg-zinc-900 hover:bg-emerald-500 hover:text-zinc-950 border border-emerald-500/10 hover:border-emerald-500/40 px-3.5 py-1.5 rounded text-xs font-bold font-sans transition-all active:scale-95 cursor-pointer"
                  >
                    <span>Trade Now</span>
                    <ArrowUpRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-[#090A0C] border border-zinc-900 rounded-lg p-10 flex flex-col items-center justify-center text-center max-w-md mx-auto shadow-2xl">
          <ShieldAlert className="w-10 h-10 text-zinc-500 pb-2" />
          <h4 className="font-display font-semibold text-zinc-300">Empty Terminal Watchlist</h4>
          <p className="text-xs text-zinc-500 mt-1 max-w-xs">
            Star favorite memecoins on the **Trending Board** to load them onto your priority tracking cockpit.
          </p>
          <button 
            onClick={() => setActiveTab('trending')}
            className="mt-4 bg-emerald-500 hover:bg-emerald-400 text-zinc-950 px-3.5 py-1.5 rounded text-xs font-bold cursor-pointer transition-all"
          >
            Explore Hot Tokens
          </button>
        </div>
      )}
    </div>
  );
}
