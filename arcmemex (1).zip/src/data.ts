import { MemeToken } from './types';

// Helper to generate realistic-looking historical candle data
function generateHistoricalCandles(basePrice: number, count: number = 50): Array<{
  time: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}> {
  const candles = [];
  let currentPrice = basePrice * 0.8; // start a bit lower
  
  // Backdate time
  const now = new Date();
  for (let i = count - 1; i >= 0; i--) {
    const timeVal = new Date(now.getTime() - i * 15 * 60 * 1000); // 15 min candles
    const timeStr = timeVal.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    
    // Random walk with positive/negative drift
    const changePercent = (Math.random() - 0.47) * 0.08; // slight positive bias
    const open = currentPrice;
    const close = currentPrice * (1 + changePercent);
    const high = Math.max(open, close) * (1 + Math.random() * 0.03);
    const low = Math.min(open, close) * (1 - Math.random() * 0.03);
    const volume = Math.round(5000 + Math.random() * 45000);
    
    candles.push({
      time: timeStr,
      open: parseFloat(open.toFixed(6)),
      high: parseFloat(high.toFixed(6)),
      low: parseFloat(low.toFixed(6)),
      close: parseFloat(close.toFixed(6)),
      volume
    });
    
    currentPrice = close;
  }
  return candles;
}

// Helper to generate realistic initial trade history
function generateInitialTrades(basePrice: number): Array<{
  time: string;
  price: number;
  size: number;
  type: 'BUY' | 'SELL';
}> {
  const trades = [];
  const now = new Date();
  for (let i = 0; i < 20; i++) {
    const timeVal = new Date(now.getTime() - i * 45000 - Math.random() * 20000);
    const isBuy = Math.random() > 0.45;
    const priceDrift = 1 + (Math.random() - 0.5) * 0.02;
    const price = parseFloat((basePrice * priceDrift).toFixed(6));
    const size = parseFloat((100 + Math.random() * 10000).toFixed(2));
    
    trades.push({
      time: timeVal.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      price,
      size,
      type: isBuy ? 'BUY' : 'SELL' as const
    });
  }
  return trades;
}

export const INITIAL_TOKENS: MemeToken[] = [
  {
    symbol: "ARC",
    name: "Arc Native Token",
    price: 1.425,
    priceChange24h: 12.8,
    volume24h: 1254300,
    liquidity: 9500000,
    supply: 100000000,
    marketCap: 142500000,
    logo: "https://cryptologos.cc/logos/arweave-ar-logo.png", // Stand-in logo or clean graphic
    description: "The core utility asset of the Arc Ecosystem. Powering fast smart contracts, low gas transactions, and terminal trading speed.",
    baseTokenAddress: "0x5042002000000000000000000000000000000001",
    tradeHistory: generateInitialTrades(1.425),
    candles: generateHistoricalCandles(1.425)
  },
  {
    symbol: "GIGA",
    name: "GigaArc Pepe",
    price: 0.00248,
    priceChange24h: 42.5,
    volume24h: 890450,
    liquidity: 450000,
    supply: 10000000000,
    marketCap: 24800000,
    logo: "https://cryptologos.cc/logos/pepe-pepe-logo.png",
    description: "The absolute biggest chad of the Arc Network. Built differently for maximum high-throughput leverage meme creation.",
    baseTokenAddress: "0x5042002000000000000000000000000000000002",
    tradeHistory: generateInitialTrades(0.00248),
    candles: generateHistoricalCandles(0.00248)
  },
  {
    symbol: "PEPEA",
    name: "Pepe Arc",
    price: 0.0000854,
    priceChange24h: -5.4,
    volume24h: 312000,
    liquidity: 180000,
    supply: 420690000000,
    marketCap: 35926926,
    logo: "https://cryptologos.cc/logos/pepe-pepe-logo.png",
    description: "Classic Pepe, but upgraded to run on Arc Testnet's sub-second finality layers. Safe, froggy, and standard.",
    baseTokenAddress: "0x5042002000000000000000000000000000000003",
    tradeHistory: generateInitialTrades(0.0000854),
    candles: generateHistoricalCandles(0.0000854)
  },
  {
    symbol: "NYAN",
    name: "Nyan Arc",
    price: 0.342,
    priceChange24h: 18.2,
    volume24h: 489000,
    liquidity: 320000,
    supply: 10000000,
    marketCap: 3420000,
    logo: "https://cryptologos.cc/logos/dogecoin-doge-logo.png", // representative placeholder
    description: "Cruising at 504,200 Giga-seconds on Arc Network. Fully decentralized pop-art internet culture token.",
    baseTokenAddress: "0x5042002000000000000000000000000000000004",
    tradeHistory: generateInitialTrades(0.342),
    candles: generateHistoricalCandles(0.342)
  },
  {
    symbol: "MEMEX",
    name: "ArcMemeX Governance",
    price: 12.85,
    priceChange24h: 8.4,
    volume24h: 2154000,
    liquidity: 14500000,
    supply: 5000000,
    marketCap: 64250000,
    logo: "https://cryptologos.cc/logos/maker-mkr-logo.png",
    description: "The governance token indexing all meme liquidity on Arc. Holders earn trading fees and voting power over the launchpad.",
    baseTokenAddress: "0x5042002000000000000000000000000000000005",
    tradeHistory: generateInitialTrades(12.85),
    candles: generateHistoricalCandles(12.85)
  },
  {
    symbol: "PUMP",
    name: "Arc Pump Token",
    price: 0.000921,
    priceChange24h: 124.9,
    volume24h: 3105000,
    liquidity: 690000,
    supply: 1000000000,
    marketCap: 921000,
    logo: "https://cryptologos.cc/logos/rocket-pool-rpl-logo.png",
    description: "Liquidity is pumped. Leverage is maxed. The official high-risk sandbox meme coin of Arc. Only real degen entries allowed.",
    baseTokenAddress: "0x5042002000000000000000000000000000000006",
    tradeHistory: generateInitialTrades(0.000921),
    candles: generateHistoricalCandles(0.000921)
  }
];
