export interface MemeToken {
  symbol: string;
  name: string;
  price: number;
  priceChange24h: number; // percentage
  volume24h: number;      // in USD
  liquidity: number;      // in USD
  supply: number;
  marketCap: number;
  logo: string;
  description: string;
  baseTokenAddress: string;
  tradeHistory: Array<{time: string; price: number; size: number; type: 'BUY' | 'SELL'}>;
  candles: Array<{time: string; open: number; high: number; low: number; close: number; volume: number}>;
}

export interface Position {
  id: string;
  symbol: string;
  name: string;
  type: 'BUY' | 'SELL';
  leverage: number;
  entryPrice: number;
  indexPrice: number;
  margin: number;
  size: number;
  liquidationPrice: number;
  unrealizedPnl: number;
  timestamp: string;
}

export interface WalletState {
  address: string | null;
  balance: string; // testnet ARC balance
  isConnected: boolean;
  chainId: number; // 5042002
  walletType: 'metamask' | 'okx' | null;
}

export interface Transaction {
  id: string;
  symbol: string;
  type: 'BUY' | 'SELL' | 'FUND' | 'CLOSE';
  amount: number;
  price: number;
  timestamp: string;
  hash: string;
  status: 'SUCCESS' | 'FAILED';
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'model';
  text: string;
  timestamp: string;
}
