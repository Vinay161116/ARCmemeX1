import { useState, useEffect, useCallback } from 'react';
import { MemeToken, Position, WalletState, Transaction, ChatMessage } from './types';
import { INITIAL_TOKENS } from './data';

export function useTradingState() {
  // Navigation & UI layout states
  const [activeTab, setActiveTab] = useState<'trade' | 'trending' | 'portfolio' | 'watchlist' | 'ai'>('trade');
  const [selectedTokenSymbol, setSelectedTokenSymbol] = useState<string>('ARC');
  
  // Blockchain Network Stats Synchronized from Server RPC
  const [networkStats, setNetworkStats] = useState({
    blockNumber: 21543810,
    gasPriceGwei: "1.50",
    rpcUrl: "https://rpc.testnet.arc.network",
    chainId: 5042002,
    explorer: "https://testnet.arcscan.app"
  });

  // Hot token lists with streaming-simulated prices
  const [tokens, setTokens] = useState<MemeToken[]>(() => {
    const saved = localStorage.getItem('arcmemex_tokens');
    return saved ? JSON.parse(saved) : INITIAL_TOKENS;
  });

  // Watchlist items (tracked by symbols)
  const [watchlist, setWatchlist] = useState<string[]>(() => {
    const saved = localStorage.getItem('arcmemex_watchlist');
    return saved ? JSON.parse(saved) : ['ARC', 'GIGA', 'MEMEX'];
  });

  // Active Positions tracking
  const [positions, setPositions] = useState<Position[]>(() => {
    const saved = localStorage.getItem('arcmemex_positions');
    return saved ? JSON.parse(saved) : [];
  });

  // Wallet Connection Config
  const [wallet, setWallet] = useState<WalletState>(() => {
    const saved = localStorage.getItem('arcmemex_wallet');
    return saved ? JSON.parse(saved) : {
      address: null,
      balance: "5.00", // Start with 5.0 ARC as initial test token faucet incentive
      isConnected: false,
      chainId: 1, // Default Ethereum/other, to allow trigger "Switch Network"
      walletType: null
    };
  });

  // Transaction Ledger Logs
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem('arcmemex_transactions');
    return saved ? JSON.parse(saved) : [];
  });

  // Active AI chats history
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [isAiLoading, setIsAiLoading] = useState(false);

  // Synchronize dynamic lists to local storage
  useEffect(() => {
    localStorage.setItem('arcmemex_tokens', JSON.stringify(tokens));
  }, [tokens]);

  useEffect(() => {
    localStorage.setItem('arcmemex_watchlist', JSON.stringify(watchlist));
  }, [watchlist]);

  useEffect(() => {
    localStorage.setItem('arcmemex_positions', JSON.stringify(positions));
  }, [positions]);

  useEffect(() => {
    localStorage.setItem('arcmemex_wallet', JSON.stringify(wallet));
  }, [wallet]);

  useEffect(() => {
    localStorage.setItem('arcmemex_transactions', JSON.stringify(transactions));
  }, [transactions]);

  // Fetch real gas and blocks from server-proxy RPC!
  const fetchNetworkStats = useCallback(async () => {
    try {
      const res = await fetch('/api/network-stats');
      const data = await res.json();
      if (data.success || data.blockNumber) {
        setNetworkStats({
          blockNumber: data.blockNumber,
          gasPriceGwei: data.gasPriceGwei,
          rpcUrl: data.rpcUrl,
          chainId: data.chainId,
          explorer: data.explorer
        });
      }
    } catch (e) {
      console.warn("Failed retrieving standard network stats proxy", e);
    }
  }, []);

  useEffect(() => {
    fetchNetworkStats();
    const inv = setInterval(fetchNetworkStats, 12000); // refresh system info every 12s
    return () => clearInterval(inv);
  }, [fetchNetworkStats]);

  // Simulated live trade triggers & price movements!
  // This executes a light fluctuating ticker that adds incredible live energy to the platform
  useEffect(() => {
    const priceTickInterval = setInterval(() => {
      setTokens((prevTokens) => {
        return prevTokens.map((t) => {
          // Adjust prices by tiny fractions
          const variance = (Math.random() - 0.49) * 0.015; // random volatility drift
          const prevPrice = t.price;
          const price = parseFloat(Math.max(0.000001, prevPrice * (1 + variance)).toFixed(t.symbol === 'PEPEA' ? 7 : t.symbol === 'GIGA' ? 5 : 3));
          const priceChange24h = parseFloat((t.priceChange24h + variance * 100).toFixed(2));
          
          // Generate simulated incoming order-book logs
          const isBuy = Math.random() > 0.46;
          const tradeSize = parseFloat((50 + Math.random() * 3000).toFixed(1));
          const tradeTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
          const newTrade = {
            time: tradeTime,
            price,
            size: tradeSize,
            type: isBuy ? 'BUY' as const : 'SELL' as const
          };
          
          const updatedHistory = [newTrade, ...t.tradeHistory.slice(0, 19)];

          // Update active candlestick (modify latest candle close, open, high, low)
          const updatedCandles = [...t.candles];
          if (updatedCandles.length > 0) {
            const lastIdx = updatedCandles.length - 1;
            const lastCandle = updatedCandles[lastIdx];
            updatedCandles[lastIdx] = {
              ...lastCandle,
              close: price,
              high: Math.max(lastCandle.high, price),
              low: Math.min(lastCandle.low, price),
              volume: lastCandle.volume + Math.round(tradeSize)
            };
          }

          return {
            ...t,
            price,
            priceChange24h,
            tradeHistory: updatedHistory,
            candles: updatedCandles,
            marketCap: Math.round(t.supply * price),
            volume24h: Math.round(t.volume24h + tradeSize * price)
          };
        });
      });
    }, 4500); // update feed every 4.5s

    return () => clearInterval(priceTickInterval);
  }, []);

  // Update active positions' indexes on price ticks
  useEffect(() => {
    if (positions.length === 0) return;
    setPositions((prev) => {
      return prev.map((pos) => {
        const liveToken = tokens.find((t) => t.symbol === pos.symbol);
        if (!liveToken) return pos;
        
        const indexPrice = liveToken.price;
        // P&L calculation: size * (indexPrice - entryPrice) for BUY, size * (entryPrice - indexPrice) for SELL
        const multiplier = pos.type === 'BUY' ? 1 : -1;
        const rawPnl = pos.size * (indexPrice - pos.entryPrice) * multiplier;
        const unrealizedPnl = parseFloat(rawPnl.toFixed(4));
        
        return {
          ...pos,
          indexPrice,
          unrealizedPnl
        };
      });
    });
  }, [tokens]);

  // Connect Wallet Action Simulator
  const connectWallet = useCallback((type: 'metamask' | 'okx') => {
    setWallet((prev) => ({
      ...prev,
      isConnecting: true
    }));

    // Beautiful simulated wallet interaction flow
    setTimeout(() => {
      const mockAddr = type === 'metamask'
        ? "0x7fd9Ea5ba98C496150420023BfdE592be5042001"
        : "0x384aA12Bc90F561e15042002e212bCd09abB2002";

      setWallet({
        address: mockAddr,
        balance: localStorage.getItem('arcmemex_arc_balance') || "150.00", // Start with 150 test ARC upon actual click!
        isConnected: true,
        chainId: 5042002, // Directly connect to Arc Testnet 5042002 representing auto swapper
        walletType: type
      });

      // Insert action tx standard notification log
      const hash = "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
      const connectTx: Transaction = {
        id: Math.random().toString(),
        symbol: "ARC",
        type: "FUND",
        amount: 150.00,
        price: 1.0,
        timestamp: new Date().toLocaleTimeString(),
        hash,
        status: "SUCCESS"
      };

      setTransactions((prev) => [connectTx, ...prev]);
    }, 800);
  }, []);

  // Switch network helper
  const switchNetworkToArc = useCallback(() => {
    if (!wallet.isConnected) return;
    setWallet((prev) => ({
      ...prev,
      chainId: 5042002
    }));
  }, [wallet.isConnected]);

  // Disconnect Wallet
  const disconnectWallet = useCallback(() => {
    setWallet({
      address: null,
      balance: "5.00",
      isConnected: false,
      chainId: 1,
      walletType: null
    });
  }, []);

  // Run ARC testnet faucet
  const runFaucet = useCallback(() => {
    if (!wallet.isConnected) return;
    const currentBal = parseFloat(wallet.balance) + 500.00;
    const newBal = currentBal.toFixed(2);
    
    setWallet((prev) => ({
      ...prev,
      balance: newBal
    }));
    localStorage.setItem('arcmemex_arc_balance', newBal);

    const hash = "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
    const faucetTx: Transaction = {
      id: Math.random().toString(),
      symbol: "ARC",
      type: "FUND",
      amount: 500.00,
      price: 1.0,
      timestamp: new Date().toLocaleTimeString(),
      hash,
      status: "SUCCESS"
    };

    setTransactions((prev) => [faucetTx, ...prev]);
  }, [wallet.isConnected, wallet.balance]);

  // Execute Trade (BUY or SELL, support limit orders or leverage contracts)
  const executeTrade = useCallback((
    symbol: string,
    type: 'BUY' | 'SELL',
    amountUsdc: number,
    leverage: number,
    entryPrice: number
  ) => {
    if (!wallet.isConnected) {
      alert("Please connect your wallet first before opening transactions.");
      return false;
    }

    if (wallet.chainId !== 5042002) {
      alert("Please switch your network to Arc Testnet in order to broadcast Web3 orders.");
      return false;
    }

    const tokenObj = tokens.find((t) => t.symbol === symbol);
    if (!tokenObj) return false;

    // Convert USDC amount to ARC equivalent for balance deduction if needed,
    // or simulate margin subtraction
    const rawMargin = amountUsdc / leverage;
    const requiredArcGas = 0.001; // minimal transaction fee

    const walletArcBalance = parseFloat(wallet.balance);
    const marginInArc = rawMargin / tokens.find(t => t.symbol === 'ARC')!.price;

    if (walletArcBalance < (marginInArc + requiredArcGas)) {
      alert(`Insufficient ARC testnet tokens! Required: ${(marginInArc + requiredArcGas).toFixed(3)} ARC. Use the free FAUCET button in the trade panel to fund.`);
      return false;
    }

    // Deduct margin from wallet balance
    const updatedBalance = (walletArcBalance - marginInArc - requiredArcGas).toFixed(2);
    setWallet((prev) => ({
      ...prev,
      balance: updatedBalance
    }));
    localStorage.setItem('arcmemex_arc_balance', updatedBalance);

    // Calculate position size (contracts)
    const positionSize = parseFloat((amountUsdc / entryPrice).toFixed(4));
    
    // Calculate liquidation price
    // Long: entryPrice * (1 - 1/leverage * 0.95), Short: entryPrice * (1 + 1/leverage * 0.95)
    const liqBuffer = 0.95;
    const liqPriceRaw = type === 'BUY'
      ? entryPrice * (1 - (1 / leverage) * liqBuffer)
      : entryPrice * (1 + (1 / leverage) * liqBuffer);
    const liquidationPrice = parseFloat(Math.max(0.000001, liqPriceRaw).toFixed(symbol === 'PEPEA' ? 7 : symbol === 'GIGA' ? 5 : 3));

    // Create new position entry
    const newPosition: Position = {
      id: Math.random().toString(),
      symbol,
      name: tokenObj.name,
      type,
      leverage,
      entryPrice,
      indexPrice: entryPrice,
      margin: parseFloat(rawMargin.toFixed(2)),
      size: positionSize,
      liquidationPrice,
      unrealizedPnl: 0.0,
      timestamp: new Date().toLocaleTimeString()
    };

    setPositions((prev) => [newPosition, ...prev]);

    // Insert trade ledger history
    const hash = "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
    const tradeTx: Transaction = {
      id: Math.random().toString(),
      symbol,
      type: type,
      amount: positionSize,
      price: entryPrice,
      timestamp: new Date().toLocaleTimeString(),
      hash,
      status: "SUCCESS"
    };

    setTransactions((prev) => [tradeTx, ...prev]);
    return true;
  }, [wallet, tokens]);

  // Close Position Action
  const closePosition = useCallback((positionId: string) => {
    const pos = positions.find((p) => p.id === positionId);
    if (!pos) return;

    // Refund margin + P&L back to ARC balance
    const arcPriceObj = tokens.find(t => t.symbol === 'ARC');
    const arcPrice = arcPriceObj ? arcPriceObj.price : 1.42;
    const refundUsdc = pos.margin + pos.unrealizedPnl;
    const refundInArc = Math.max(0, refundUsdc / arcPrice);

    setWallet((prev) => {
      const currentBal = parseFloat(prev.balance);
      const newBal = (currentBal + refundInArc).toFixed(2);
      localStorage.setItem('arcmemex_arc_balance', newBal);
      return {
        ...prev,
        balance: newBal
      };
    });

    // Remove position
    setPositions((prev) => prev.filter((p) => p.id !== positionId));

    // Ledger receipt logging
    const hash = "0x" + Array.from({ length: 64 }, () => Math.floor(Math.random() * 16).toString(16)).join("");
    const closeTx: Transaction = {
      id: Math.random().toString(),
      symbol: pos.symbol,
      type: "CLOSE",
      amount: pos.size,
      price: pos.indexPrice,
      timestamp: new Date().toLocaleTimeString(),
      hash,
      status: "SUCCESS"
    };

    setTransactions((prev) => [closeTx, ...prev]);
  }, [positions, tokens]);

  // Watchlist addition/removal controls
  const toggleWatchlist = useCallback((symbol: string) => {
    setWatchlist((prev) => {
      if (prev.includes(symbol)) {
        return prev.filter((s) => s !== symbol);
      } else {
        return [...prev, symbol];
      }
    });
  }, []);

  // Send message to Gemini Artificial Advisor
  const sendAiChatMessage = useCallback(async (msgText: string) => {
    if (!msgText.trim()) return;

    const userMessage: ChatMessage = {
      id: Math.random().toString(),
      role: 'user',
      text: msgText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages((prev) => [...prev, userMessage]);
    setIsAiLoading(true);

    try {
      const activeTokenObj = tokens.find(t => t.symbol === selectedTokenSymbol);
      const response = await fetch('/api/gemini/advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: msgText,
          history: chatMessages.slice(-8), // send last 8 messages for context
          currentToken: selectedTokenSymbol
        })
      });
      const data = await response.json();
      
      const aiMessage: ChatMessage = {
        id: Math.random().toString(),
        role: 'model',
        text: data.text || "I found a temporal glitch in the Arc Testnet nodes. Send an order block to trigger calibration!",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setChatMessages((prev) => [...prev, aiMessage]);
    } catch (e) {
      const errorMessage: ChatMessage = {
        id: Math.random().toString(),
        role: 'model',
        text: "🚨 Connection timeout with Sentinel AI oracle Node. Please check internet connections or config.",
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setChatMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsAiLoading(false);
    }
  }, [chatMessages, selectedTokenSymbol, tokens]);

  return {
    activeTab,
    setActiveTab,
    selectedTokenSymbol,
    setSelectedTokenSymbol,
    tokens,
    watchlist,
    toggleWatchlist,
    positions,
    wallet,
    connectWallet,
    disconnectWallet,
    switchNetworkToArc,
    runFaucet,
    executeTrade,
    closePosition,
    transactions,
    networkStats,
    chatMessages,
    isAiLoading,
    sendAiChatMessage,
    setChatMessages
  };
}
